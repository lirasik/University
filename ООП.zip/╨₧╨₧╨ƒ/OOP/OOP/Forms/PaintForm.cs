﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

using OOP.Figures;

namespace OOP
{
    public partial class PaintForm : Form
    {
        private List<Figure> figuresList;
        private Size canvasSize;
        private bool isSaved = false;

        private Figure drawingFigure;
        private Point firstPosition;
        private Point secondPosition;
        private Point cursorFirstPosition;
        private Point cursorSecondPosition;
        private Point offset = Point.Empty;
        private bool isDrawing = false;
        private bool hasSelections = false;
        private Figure selectedFigure = null;
        private MarkerID resizingDestination = MarkerID.None;

        private MainForm Redactor
        {
            get
            {
                return ((MainForm)MdiParent);
            }
        }

        private BufferedGraphics buffered;

        public List<Figure> FiguresList { get => figuresList; set => figuresList = value; }
        public Size CanvasSize { get => canvasSize; set => canvasSize = value; }
        public bool IsSaved { get => isSaved; set => isSaved = value; }
        public bool HasSelections
        {
            get
            {
                return hasSelections;
            }
            private set
            {
                hasSelections = value;
                Redactor.UpdateEditButtons();
            }
        }
        public Figure SelectedFigure { get => selectedFigure; set => selectedFigure = value; }

        public PaintForm(Size s)
        {
            CanvasSize = s;
            InitializeComponent();
            AutoScrollMinSize = CanvasSize;
            Size = CanvasSize + PreferredSize;
            figuresList = new List<Figure>();
        }

        private void PaintForm_MouseDown(object sender, MouseEventArgs e)
        {
            cursorFirstPosition = cursorSecondPosition = Cursor.Position;
            firstPosition = new Point(e.X - AutoScrollPosition.X, e.Y - AutoScrollPosition.Y);
            if (e.Button == MouseButtons.Left && !isDrawing)
            {
                LeftMouseDown();
            }
        }

        private void LeftMouseDown()
        {
            isDrawing = true;
            if (HasSingleSelection)
            {
                resizingDestination = GetClickedMarkerID();
            }
            if (resizingDestination == MarkerID.None)
            {
                try
                {
                    drawingFigure = CreateFigure();
                    UpdateSelections();
                }
                catch (Exception)
                {
                    isDrawing = false;
                }
            }
        }

        private MarkerID GetClickedMarkerID() => selectedFigure.GetMarkerID(firstPosition, AutoScrollPosition);

        private void UpdateSelections()
        {
            if (HasSelections)
            {
                if (!IsClickInsideSelections())
                {
                    DeselectAll();
                }
            }
        }

        private bool IsClickInsideSelections()
        {
            return FiguresList.Any(
                figure => figure.Selected &&
                IsClickInside(figure));
        }

        private System.Drawing.Rectangle GetSelectionArea() => drawingFigure.GetMarginArea(AutoScrollPosition);

        public Figure CreateFigure()
        {
            return CreateFigure(Redactor.CurrentFigure, firstPosition);
        }
        public Figure CreateFigure(FigureType figureType, Point firstPosition)
        {
            var bgColor = Redactor.CurrentBackgroundColor;
            var lColor = Redactor.CurrentLineColor;
            var lWidth = Redactor.CurrentLineWidth;
            var isFilledF = Redactor.IsFilledFigure;
            var font = Redactor.CurrentFont;
            switch (figureType)
            {
                case FigureType.Rectangle:
                    return new OOP.Figures.Rectangle(firstPosition)
                    {
                        BackgroundColor = bgColor,
                        LineColor = lColor,
                        LineWidth = lWidth,
                        Filled = isFilledF
                    };
                case FigureType.Ellipse:
                    return new OOP.Figures.Ellipse(firstPosition)
                    {
                        BackgroundColor = bgColor,
                        LineColor = lColor,
                        LineWidth = lWidth,
                        Filled = isFilledF
                    };
                case FigureType.Line:
                    return new OOP.Figures.Line(firstPosition)
                    {
                        BackgroundColor = bgColor,
                        LineColor = lColor,
                        LineWidth = lWidth
                    };
                case FigureType.Curve:
                    return new OOP.Figures.Curve(firstPosition)
                    {
                        BackgroundColor = bgColor,
                        LineColor = lColor,
                        LineWidth = lWidth
                    };
                case FigureType.Text:
                    return new OOP.Figures.Text(firstPosition)
                    {
                        BackgroundColor = bgColor,
                        LineColor = lColor,
                        LineWidth = 1,
                        Font = font
                    };
                case FigureType.Cursor:
                    return new OOP.Figures.Rectangle(firstPosition, isCursor: true);
                default:
                    throw new Exception("This figure type has no implementation.");
            }
        }

        private void PaintForm_MouseMove(object sender, MouseEventArgs e)
        {
            cursorSecondPosition = Cursor.Position;
            secondPosition = new Point(e.X - AutoScrollPosition.X, e.Y - AutoScrollPosition.Y);
            Redactor.ShowCursorPosition(secondPosition);
            if (e.Button == MouseButtons.Left)
            {
                LeftMouseMove();
            }
        }

        private void LeftMouseMove()
        {
            if (isDrawing)
            {
                buffered.Render();
                if (HasSelections)
                {
                    offset.X = cursorSecondPosition.X - cursorFirstPosition.X;
                    offset.Y = cursorSecondPosition.Y - cursorFirstPosition.Y;
                    Refresh();
                }
                else
                {
                    drawingFigure.Update(firstPosition, secondPosition);
                    if (drawingFigure.Type == FigureType.Cursor)
                    {
                        UpdateFigureSelection();
                    }
                    DrawCurrentFigure();
                }
            }
        }
        private void UpdateFigureSelection()
        {
            FiguresList.ForEach(figure =>
                figure.Selected = IsClickInside(figure));
            Refresh();
        }

        private void DrawCurrentFigure()
        {
            Refresh();
            Graphics g = CreateGraphics();
            if (drawingFigure.Type == FigureType.Cursor)
            {
                drawingFigure.DrawArea(g, AutoScrollPosition);
            }
            else
            {
                if (Redactor.SnapToGrid &&
                    drawingFigure.Type != FigureType.Curve)
                {
                    drawingFigure.Align(Redactor.GridPitch);
                }
                drawingFigure.DrawDash(g, AutoScrollPosition);
            }
            g.Dispose();
        }

        private void PaintForm_MouseUp(object sender, MouseEventArgs e)
        {
            cursorSecondPosition = Cursor.Position;
            secondPosition = new Point(e.X - AutoScrollPosition.X, e.Y - AutoScrollPosition.Y);
            if (e.Button == MouseButtons.Left)
            {
                LeftMouseUp();
            }
        }

        private void LeftMouseUp()
        {
            if (isDrawing &&
                IsInsideCanvas(drawingFigure.FirstPoint) &&
                IsInsideCanvas(drawingFigure.SecondPoint))
            {
                if (drawingFigure.Type == FigureType.Cursor)
                {
                    if (HasSingleSelection&& resizingDestination != MarkerID.None)
                    {
                        if (IsResizedFigureInsideCanvas(resizingDestination, offset))
                        {
                            ResizeSelectedFigure();
                        }
                    }
                    else
                    {
                        ProcessSelections();
                    }
                }
                else
                {
                    AddFigure();
                }
            }
            isDrawing = false;
            offset = Point.Empty;
            Invalidate();
        }

        private void ResizeSelectedFigure()
        {
            selectedFigure.Resize(resizingDestination, offset);
            resizingDestination = MarkerID.None;
            if (Redactor.SnapToGrid)
            {
                selectedFigure.Align(Redactor.GridPitch);
            }
        }

        private void AddFigure()
        {
            if (drawingFigure.Type == FigureType.Text)
            {
                AddText();
            }
            else
            {
                if (Redactor.SnapToGrid &&
                    drawingFigure.Type == FigureType.Curve)
                {
                    drawingFigure.Align(Redactor.GridPitch);
                }
                FiguresList.Add(drawingFigure);
            }
        }

        private void AddText()
        {
            ShowTextInputBox();
            if (((OOP.Figures.Text)drawingFigure).Inner != "")
            {
                FiguresList.Add(drawingFigure);
            }
        }

        private void ProcessSelections()
        {
            if (HasSelections)
            {
                if (IsShiftedFiguresInsideCanvas(offset))
                    MoveSelectedFigures(offset);
            }
            if (FiguresList.Any(figure => figure.Selected))
            {
                HasSelections = true;
            }
            else
            {
                HasSelections = false;
            }
        }

        private bool IsResizedFigureInsideCanvas(MarkerID destination, Point resize)
        {
            var possiblePoints = selectedFigure.GetResizedPoints(destination, resize);
            if (IsInsideCanvas(possiblePoints.Item1) && IsInsideCanvas(possiblePoints.Item2))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        private bool IsShiftedFiguresInsideCanvas(Point shift)
        {
            foreach (var figure in FiguresList)
            {
                if (figure.Selected == true)
                {
                    var firstPoint = new Point(
                        figure.FirstPoint.X + shift.X,
                        figure.FirstPoint.Y + shift.Y);
                    var secondPoint = new Point(
                        figure.SecondPoint.X + shift.X,
                        figure.SecondPoint.Y + shift.Y);
                    if (!IsInsideCanvas(firstPoint) || !IsInsideCanvas(secondPoint))
                    {
                        return false;
                    }
                }
            }
            return true;
        }

        private void MoveSelectedFigures(Point shift)
        {
            foreach (var figure in FiguresList)
            {
                if (figure.Selected == true)
                {
                    figure.Move(shift);
                    if (Redactor.SnapToGrid)
                    {
                        figure.Align(Redactor.GridPitch);
                    }
                }
            }
        }

        private void TextBox_KeyPress_drawingFigure(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                ((OOP.Figures.Text)drawingFigure).Inner = ((TextBox)sender).Text;
                ((Form)((TextBox)sender).Parent).Close();
            }
        }

        private void ShowTextInputBox()
        {
            var desktopLocation = new Point(
                    Math.Min(cursorFirstPosition.X, cursorSecondPosition.X),
                    Math.Min(cursorFirstPosition.Y, cursorSecondPosition.Y));
            ShowTextInputBox(desktopLocation, drawingFigure.Size);
        }

        private void ShowTextInputBox(Point desktopLocation, Size formSize)
        {
            var textForm = new Form()
            {
                FormBorderStyle = FormBorderStyle.None,
                StartPosition = FormStartPosition.Manual,
                BackColor = Color.White,
                TransparencyKey = Color.White,
                DesktopLocation = desktopLocation,
                Size = formSize
            };
            var textBox = new TextBox()
            {
                Font = ((MainForm)MdiParent).CurrentFont,
                ForeColor = ((MainForm)MdiParent).CurrentLineColor,
                Multiline = true,
                Size = textForm.Size,
                Parent = textForm,
                Visible = true
            };
            textBox.KeyPress += TextBox_KeyPress_drawingFigure;
            textForm.ShowDialog();
        }
        private void TextBox_KeyPress_selectedFigure(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                ((OOP.Figures.Text)selectedFigure).Inner = ((TextBox)sender).Text;
                ((Form)((TextBox)sender).Parent).Close();
            }
        }
        private void ShowTextEditBox(Point desktopLocation, Size formSize)
        {
            var selectedText = ((OOP.Figures.Text)selectedFigure);
            var textForm = new Form()
            {
                FormBorderStyle = FormBorderStyle.None,
                StartPosition = FormStartPosition.Manual,
                BackColor = Color.White,
                TransparencyKey = Color.White,
                DesktopLocation = desktopLocation,
                Size = formSize,
                Padding = Padding.Empty
            };
            var textBox = new TextBox()
            {
                Font = selectedText.Font,
                ForeColor = selectedText.LineColor,
                Multiline = true,
                Size = textForm.Size,
                Parent = textForm,
                Visible = true,
                Text = selectedText.Inner,
                Margin = Padding.Empty
            };
            textBox.KeyPress += TextBox_KeyPress_selectedFigure;
            selectedText.Inner = "";
            Refresh();
            textForm.ShowDialog();
        }

        private bool IsInsideCanvas(Point p)
        {
            return p.X <= canvasSize.Width && p.Y <= canvasSize.Height &&
                   p.X >= 0                && p.Y >= 0;
        }

        private void PaintForm_Paint(object sender, PaintEventArgs e)
        {
            buffered.Graphics.Clear(BackColor);
            DrawCanvas();
            if (Redactor.ShowGrid)
            {
                DrawGrid();
            }
            DrawFigures();
            DrawSingleSelectedFigure();
            buffered.Render(e.Graphics);
        }

        private void DrawFigures()
        {
            FiguresList.ForEach(figure =>
            {
                if (figure.Selected)
                {
                    if (!HasSingleSelection)
                    {
                        figure.DrawMoved(buffered.Graphics, AutoScrollPosition, offset);
                    }
                }
                else
                {
                    figure.Draw(buffered.Graphics, AutoScrollPosition);
                }
            });
        }

        private void DrawSingleSelectedFigure()
        {
            if (HasSingleSelection)
            {
                if (resizingDestination != MarkerID.None)
                {
                    selectedFigure.DrawResized(
                        buffered.Graphics, AutoScrollPosition, resizingDestination, offset);
                }
                else
                {
                    selectedFigure.DrawMoved(buffered.Graphics, AutoScrollPosition, offset);
                    selectedFigure.DrawMarkers(buffered.Graphics, AutoScrollPosition, offset);
                }
            }
        }

        public void AlignFigures()
        {
            FiguresList.ForEach(figure =>
            {
                figure.Align(Redactor.GridPitch);
            });
        }

        private void PaintForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            switch (MessageBox.Show(Text, "Сохранить документ?", MessageBoxButtons.YesNoCancel))
            {
                case DialogResult.Yes:
                    Redactor.Save_Click(sender, e);
                    return;
                case DialogResult.No:
                    return;
                case DialogResult.Cancel:
                    e.Cancel = true;
                    return;
            }
        }

        private void PaintForm_Load(object sender, EventArgs e)
        {
            BufferedGraphicsManager.Current.MaximumBuffer = SystemInformation.PrimaryMonitorMaximizedWindowSize;
            buffered = BufferedGraphicsManager.Current.Allocate(CreateGraphics(), DisplayRectangle);
            DrawCanvas();
        }

        private void DrawCanvas()
        {
            buffered.Graphics.Clear(Color.White);
            new OOP.Figures.Rectangle(Point.Empty, new Point(CanvasSize))
            {
                Filled = true,
                BackgroundColor = Color.White,
                LineColor = Color.White,
                LineWidth = 0
            }.Draw(buffered.Graphics, AutoScrollPosition);
        }

        private void PaintForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            buffered.Dispose();
        }

        private void PaintForm_Activated(object sender, EventArgs e)
        {
            Redactor.ShowCanvasSize(canvasSize);
        }

        public void DeselectAll()
        {
            FiguresList.ForEach(figure => figure.Selected = false);
            HasSelections = false;
            selectedFigure = null;
            resizingDestination = MarkerID.None;
            Refresh();
        }

        public List<Figure> GetSelectedFigures() => FiguresList.Where(figure => figure.Selected).ToList();

        public void DeleteSelectedFigures()
        {
            FiguresList = FiguresList.Where(figure => !figure.Selected).ToList();
            DeselectAll();
            Refresh();
        }

        private void PaintForm_Leave(object sender, EventArgs e)
        {
            Redactor.ShowCanvasSize();
            Redactor.ShowEmptyCursorPosition();
        }

        public void SelectAll()
        {
            if (FiguresList.Count > 0)
            {
                FiguresList.ForEach(figure => figure.Selected = true);
                HasSelections = true;
                Refresh();
            }
        }

        public void AddFigures(List<Figure> figures)
        {
            figuresList.AddRange(figures);
            HasSelections = true;
            Refresh();
        }

        private void DrawGrid()
        {
            var gridPen = new Pen(Color.LightGray, 1)
            {
                DashStyle = System.Drawing.Drawing2D.DashStyle.Dash
            };
            var gridPitch = Redactor.GridPitch;
            for (int row = 0; row < CanvasSize.Width; row += gridPitch)
            {
                buffered.Graphics.DrawLine(gridPen, new Point(row, 0), new Point(row, CanvasSize.Height));
            }
            for (int column = 0; column < CanvasSize.Width; column += gridPitch)
            {
                buffered.Graphics.DrawLine(gridPen, new Point(0, column), new Point(CanvasSize.Width, column));
            }
        }

        public bool IsClickInside(Figure figure)
        {
            return figure.GetMarginArea(AutoScrollPosition).IntersectsWith(GetSelectionArea());
        }

        private void PaintForm_DoubleClick(object sender, EventArgs e)
        {
            if (e is MouseEventArgs args && args.Button == MouseButtons.Left)
            {
                LeftMouseDoubleClick();
            }
        }

        private void LeftMouseDoubleClick()
        {
            if (Redactor.CurrentFigure == FigureType.Cursor)
            {
                if (figuresList.Any(figure => IsClickInside(figure)))
                {
                    if (HasSingleSelection && SelectedFigure.Type == FigureType.Text && IsClickInside(SelectedFigure))
                    {
                        ShowTextEditBox(PointToScreen(SelectedFigure.FirstPoint), SelectedFigure.Size);
                    }
                    else
                    {
                        SelectFigureUnderCursor();
                    }
                }
            }
        }

        public bool HasSingleSelection => selectedFigure != null;
        private void SelectFigureUnderCursor()
        {
            DeselectAll();
            HasSelections = true;
            selectedFigure = figuresList.First(figure => IsClickInside(figure));
            selectedFigure.Selected = true;
        }

        public void SelectFigure(int index)
        {
            DeselectAll();
            HasSelections = true;
            selectedFigure = figuresList[index];
            selectedFigure.Selected = true;
        }

        public void UpdateFiguresParams()
        {
            figuresList.ForEach(figure =>
            {
                UpdateFigureParams(figure);
            });
        }
        public void UpdateFigureParams(Figure figure)
        {
            var size = figure.Size;
            var difference = new Point(
                size.Width - canvasSize.Width,
                size.Height - canvasSize.Height);
            var resize = new Point(
                difference.X < 0 ? 0 : -difference.X,
                difference.Y < 0 ? 0 : -difference.Y);
            figure.Resize(MarkerID.BottomMiddle, resize);
            figure.Resize(MarkerID.MiddleRight, resize);

            var leftTop = figure.FirstPoint;
            var move = new Point(
                leftTop.X > 0 ? 0 : -leftTop.X,
                leftTop.Y > 0 ? 0 : -leftTop.Y);
            figure.Move(move);

            var rightBottom = figure.SecondPoint;
            var outCanvas = new Point(
                rightBottom.X - canvasSize.Width,
                rightBottom.Y - canvasSize.Height);
            move = new Point(
                outCanvas.X < 0 ? 0 : -outCanvas.X,
                outCanvas.Y < 0 ? 0 : -outCanvas.Y);
            figure.Move(move);
        }
    }
}
