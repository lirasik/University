﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OOP.Forms
{
    public partial class WidthDialog : Form
    {
        public int width;
        public WidthDialog(float width)
        {
            InitializeComponent();
            comboBox1.Text = width.ToString();
        }

        private void ButtonOK_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.OK;
        }

        private void ButtonCancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
        }

        private void comboBox1_TextChanged(object sender, EventArgs e)
        {
            int.TryParse(comboBox1.Text, out width);
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void WidthDialog_Load(object sender, EventArgs e)
        {

        }
    }
}
