﻿using OOP.Figures;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace OOP.Forms
{
    public partial class EditForm : Form
    {
        private readonly PaintForm canvas;
        private Figure figure;

        public EditForm(PaintForm canvas)
        {
            InitializeComponent();
            this.canvas = canvas;
            canvas.DeselectAll();
            InitializeFiguresListView();
        }

        private void InitializeFiguresListView()
        {
            figuresListView.Items.Clear();
            int count = 0;
            foreach (var figure in canvas.FiguresList)
            {
                var itemColumns = new string[] {
                    count++.ToString(),
                    figure.Type.ToString(),
                    string.Format("{0}, {1}", figure.FirstPoint.X, figure.FirstPoint.Y),
                };
                figuresListView.Items.Add(new ListViewItem(itemColumns));
            }
        }

        private void FiguresListView_SelectedIndexChanged(object sender, EventArgs e)
        {
            UpdateFigureEditControlls();
        }

        private void UpdateFigureEditControlls()
        {
            flowLayoutPanel.Controls.Clear();
            UpdateButtons();
            if (HasSelectedIndices)
            {
                var figureIndex = SelectedIndex;
                canvas.SelectFigure(figureIndex);
                canvas.Refresh();
                figure = canvas.SelectedFigure;
                flowLayoutPanel.Controls.AddRange(figure.GetControls().ToArray());
                flowLayoutPanel.SetFlowBreak(canvas, true);
            }
            else
            {
                figure = null;
                canvas.DeselectAll();
            }
        }

        private void UpdateButtons()
        {
            deleteButton.Enabled = saveButton.Enabled
                = HasSelectedIndices;
            toUpButton.Enabled = toStartButton.Enabled = HasSelectedIndices && SelectedIndex != 0;
            toBottomButton.Enabled = toBackButton.Enabled = HasSelectedIndices && SelectedIndex != FiguresCount - 1;
        }

        private int FiguresCount => figuresListView.Items.Count;
        private int SelectedIndex => figuresListView.SelectedIndices[0];
        private bool HasSelectedIndices => figuresListView.SelectedIndices.Count > 0;

        private void UpdateAll()
        {
            canvas.Refresh();
            InitializeFiguresListView();
            UpdateFigureEditControlls();
        }
        private void UpdateAll(int index)
        {
            canvas.Refresh();
            InitializeFiguresListView();
            figuresListView.SelectedIndices.Add(index);
            UpdateFigureEditControlls();
        }

        private void SaveButton_Click(object sender, EventArgs e)
        {
            figure.SetParameters(flowLayoutPanel.Controls);
            canvas.UpdateFigureParams(figure);
            UpdateAll();
        }

        private void DeleteButton_Click(object sender, EventArgs e)
        {
            canvas.FiguresList.Remove(figure);
            UpdateAll();
        }

        private void CloseButton_Click(object sender, EventArgs e)
        {
            UpdateAll();
            Close();
        }

        private void ChangeFigureLayout(int index)
        {
            canvas.FiguresList.Remove(figure);
            canvas.FiguresList.Insert(index, figure);
            UpdateAll(index);
        }

        private void ToUpButton_Click(object sender, EventArgs e)
        {
            var newIndex = SelectedIndex - 1;
            ChangeFigureLayout(newIndex);
        }

        private void ToStartButton_Click(object sender, EventArgs e)
        {
            var newIndex = 0;
            ChangeFigureLayout(newIndex);
        }

        private void ToBottomButton_Click(object sender, EventArgs e)
        {
            var newIndex = SelectedIndex + 1;
            ChangeFigureLayout(newIndex);
        }

        private void ToBackButton_Click(object sender, EventArgs e)
        {
            var newIndex = FiguresCount - 1;
            ChangeFigureLayout(newIndex);
        }

        private void AddButton_Click(object sender, EventArgs e)
        {
            var figureForm = new FigureForm();
            if (figureForm.ShowDialog() == DialogResult.OK)
            {
                FigureType figureType = figureForm.selectedFigureType;
                canvas.FiguresList.Add(canvas.CreateFigure(figureType, Point.Empty));
                var newIndex = FiguresCount;
                UpdateAll(newIndex);
            }
        }
    }
}
