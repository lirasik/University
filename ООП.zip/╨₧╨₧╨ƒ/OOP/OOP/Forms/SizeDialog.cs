﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OOP.Forms
{
    public partial class SizeDialog : Form
    {
        public Size size = new Size(width: 320, height: 240);
        public SizeDialog(Size s)
        {
            InitializeComponent();
        }

        private void CustomSizeCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            if (CustomSizeCheckBox.Checked)
            {
                SizeChoiceGroupBox.Enabled = false;
                HeightTextBox.Enabled = WidthTextBox.Enabled = true;
                WidthTextBox_TextChanged(sender, e);
                HeightTextBox_TextChanged(sender, e);
            }
            else
            {
                SizeChoiceGroupBox.Enabled = true;
                HeightTextBox.Enabled = WidthTextBox.Enabled = false;
                if (SizeRadio1.Checked)
                {
                    SizeRadio1_CheckedChanged(sender, e);
                }
                else if (SizeRadio2.Checked)
                {
                    SizeRadio2_CheckedChanged(sender, e);
                }
                else
                {
                    SizeRadio3_CheckedChanged(sender, e);
                }
            }
        }

        private void OKButton_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.OK;
        }

        private void CancelButton_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
        }

        private void SizeRadio1_CheckedChanged(object sender, EventArgs e)
        {
            size = new Size(width: 320, height: 240);
        }
        private void SizeRadio2_CheckedChanged(object sender, EventArgs e)
        {
            size = new Size(width: 640, height: 480);
        }
        private void SizeRadio3_CheckedChanged(object sender, EventArgs e)
        {
            size = new Size(width: 800, height: 600);
        }

        private void WidthTextBox_TextChanged(object sender, EventArgs e)
        {
            if (int.TryParse(WidthTextBox.Text, out int width))
            {
                size.Width = width;
            }

        }

        private void HeightTextBox_TextChanged(object sender, EventArgs e)
        {
            if (int.TryParse(WidthTextBox.Text, out int height))
            {
                size.Height = height;
            }
        }

        private void SizeChoiceGroupBox_Enter(object sender, EventArgs e)
        {

        }

        private void SizeDialog_Load(object sender, EventArgs e)
        {

        }
    }
}
