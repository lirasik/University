﻿using OOP.Figures;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OOP.Forms
{
    public partial class FigureForm : Form
    {
        public FigureType selectedFigureType = FigureType.Rectangle;
        public FigureForm()
        {
            InitializeComponent();
        }

        private void ButtonOK_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.OK;
        }

        private void ButtonCancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
        }

        private void FigureTypeComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            var selectedIndex = figureTypeComboBox.SelectedIndex;
            switch (selectedIndex)
            {
                case 0:
                    selectedFigureType = FigureType.Rectangle;
                    break;
                case 1:
                    selectedFigureType = FigureType.Ellipse;
                    break;
                case 2:
                    selectedFigureType = FigureType.Line;
                    break;
                case 3:
                    selectedFigureType = FigureType.Curve;
                    break;
                case 4:
                    selectedFigureType = FigureType.Text;
                    break;
                default:
                    break;
            }
        }
    }
}
