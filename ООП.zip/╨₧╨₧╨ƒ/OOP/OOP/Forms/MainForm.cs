﻿using OOP.Figures;
using OOP.Forms;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Windows.Forms;

namespace OOP
{
    public partial class MainForm : Form
    {
        private Size basicSize = new Size(width: 320, height: 240);
        private Color currentLineColor = Color.Black;
        private Color currentBackgroundColor = Color.White;
        private int currentLineWidth = 1;
        private FigureType currentFigure = FigureType.Rectangle;
        private Font currentFont = new Font("Times New Roman", 12);

        private const string formatName = "GGRFormat";

        private bool showGrid = false;
        private bool snapToGrid = false;
        private int gridPitch = 10;

        public Color CurrentLineColor
        {
            get
            {
                return currentLineColor;
            }

            private set
            {
                currentLineColor = value;
                ShowLineColor(value);
            }
        }
        public Color CurrentBackgroundColor
        {
            get
            {
                return currentBackgroundColor;
            }

            private set
            {
                currentBackgroundColor = value;
                ShowBackgroundColor(value);
            }
        }
        public int CurrentLineWidth
        {
            get
            {
                return currentLineWidth;
            }

            private set
            {
                currentLineWidth = value;
                ShowLineWidth(value);
            }
        }
        public FigureType CurrentFigure
        {
            get
            {
                return currentFigure;
            }

            private set
            {
                currentFigure = value;
                UpdateFigureButtons(value);
                ShowFont(CurrentFont);
            }
        }
        public Font CurrentFont
        {
            get
            {
                return currentFont;
            }

            private set
            {
                currentFont = value;
                ShowFont(value);
            }
        }

        public PaintForm ActiveCanvas
        {
            get
            {
                return (PaintForm)ActiveMdiChild;
            }
        }

        public bool IsFilledFigure { get => fillToolStripMenuItem.Checked; }
        public bool ShowGrid { get => showGrid; }
        public bool SnapToGrid { get => snapToGrid; }
        public int GridPitch { get => gridPitch; }

        public MainForm()
        {
            InitializeComponent();
            UpdateEditButtons();
            UpdateFillButtons();
        }

        private void New_Click(object sender, EventArgs e)
        {
            var form = new PaintForm(basicSize)
            {
                MdiParent = this,
                Text = "Рисунок " + MdiChildren.Length.ToString()
            };
            form.Show();
            ShowCanvasSize(basicSize);
            UpdateSaveButtons();
            UpdateEditButtons();
            UpdateFigureButtons(CurrentFigure);
        }

        private void ProjectToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UpdateSaveButtons();
        }

        private void UpdateSaveButtons()
        {
            if (MdiChildren.Length > 0)
            {
                saveAsToolStripMenuItem.Enabled = saveToolStripMenuItem.Enabled = true;
                saveToolStripButton.Enabled = saveAsToolStripButton.Enabled = true;
            }
            else
            {
                saveAsToolStripMenuItem.Enabled = saveToolStripMenuItem.Enabled = false;
                saveToolStripButton.Enabled = saveAsToolStripButton.Enabled = false;
            }
        }

        private void Open_Click(object sender, EventArgs e)
        {
            var openFileDialog = new OpenFileDialog
            {
                InitialDirectory = Environment.CurrentDirectory,
                Filter = "GGR files | *.ggr"
            };
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                var fileName = openFileDialog.FileName;
                var formatter = new BinaryFormatter();
                var stream = new FileStream(fileName, FileMode.Open, FileAccess.Read, FileShare.Read);
                var size = (Size)formatter.Deserialize(stream);
                var lFigures = (List<Figure>)formatter.Deserialize(stream);
                var form = new PaintForm(size)
                {
                    MdiParent = this,
                    FiguresList = lFigures,
                    Text = fileName,
                    IsSaved = true
                };
                stream.Close();
                form.Show();
            }
            UpdateSaveButtons();
            UpdateEditButtons();
        }

        public void Save_Click(object sender, EventArgs e)
        {
            var form = (PaintForm)ActiveMdiChild;
            if (form.IsSaved)
            {
                string fileName = form.Text;
                SavePicture(ref fileName, ref form);
            }
            else
            {
                SaveAs_Click(sender, e);
            }
        }

        private void SaveAs_Click(object sender, EventArgs e)
        {
            var form = ActiveCanvas;
            var saveFileDialog = new SaveFileDialog
            {
                InitialDirectory = Environment.CurrentDirectory,
                Filter = "GGR files | *.ggr",
                DefaultExt = "ggr"
            };
            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                string fileName = saveFileDialog.FileName;
                SavePicture(ref fileName, ref form);
                form.Text = fileName;
                form.IsSaved = true;
            }
        }

        private void SavePicture(ref string fileName, ref PaintForm form)
        {
            var formatter = new BinaryFormatter();
            var stream = new FileStream(fileName, FileMode.Create, FileAccess.Write, FileShare.None);
            formatter.Serialize(stream, form.CanvasSize);
            formatter.Serialize(stream, form.FiguresList);
            stream.Close();
            UpdateSaveButtons();
            UpdateEditButtons();
            ShowCanvasSize();
        }

        private void LineColor_Click(object sender, EventArgs e)
        {
            var colorDialog = new ColorDialog()
            {
                Color = currentLineColor
            };
            if (colorDialog.ShowDialog() == DialogResult.OK)
            {
                if (ActiveCanvas != null && ActiveCanvas.HasSingleSelection)
                {
                    ActiveCanvas.SelectedFigure.LineColor = colorDialog.Color;
                    ActiveCanvas.Refresh();
                }
                else
                {
                    CurrentLineColor = colorDialog.Color;
                }
            }
        }

        private void FillColor_Click(object sender, EventArgs e)
        {
            var colorDialog = new ColorDialog()
            {
                Color = currentBackgroundColor
            };
            if (colorDialog.ShowDialog() == DialogResult.OK)
            {
                if (ActiveCanvas != null && ActiveCanvas.HasSingleSelection)
                {
                    ActiveCanvas.SelectedFigure.BackgroundColor = colorDialog.Color;
                    ActiveCanvas.Refresh();
                }
                else
                {
                    CurrentBackgroundColor = colorDialog.Color;
                }
            }
        }

        private void LineWidth_Click(object sender, EventArgs e)
        {
            var widthDialog = new WidthDialog(CurrentLineWidth);
            if (widthDialog.ShowDialog() == DialogResult.OK)
            {
                if (ActiveCanvas != null && ActiveCanvas.HasSingleSelection)
                {
                    ActiveCanvas.SelectedFigure.LineWidth = widthDialog.width;
                    ActiveCanvas.Refresh();
                }
                else
                {
                    CurrentLineWidth = widthDialog.width;
                }
            }
        }

        private void CanvasSize_Click(object sender, EventArgs e)
        {
            var sizeDialog = new SizeDialog(basicSize);
            if (sizeDialog.ShowDialog() == DialogResult.OK)
            {
                basicSize = sizeDialog.size;
            }
        }

        private void FillCheck_Click(object sender, EventArgs e)
        {
            if (ActiveCanvas != null && ActiveCanvas.HasSingleSelection)
            {
                ActiveCanvas.SelectedFigure.Filled = !ActiveCanvas.SelectedFigure.Filled;
                ActiveCanvas.Refresh();
            }
            fillToolStripMenuItem.Checked = !fillToolStripMenuItem.Checked;
            fillCheckToolStripButton.Checked = !fillCheckToolStripButton.Checked;
        }

        private void Line_Click(object sender, EventArgs e)
        {
            CurrentFigure = FigureType.Line;
        }

        private void Curve_Click(object sender, EventArgs e)
        {
            CurrentFigure = FigureType.Curve;
        }

        private void Rectangle_Click(object sender, EventArgs e)
        {
            CurrentFigure = FigureType.Rectangle;
        }

        private void Ellipse_Click(object sender, EventArgs e)
        {
            CurrentFigure = FigureType.Ellipse;
        }

        private void UpdateFillButtons(bool b)
        {
            fillToolStripMenuItem.Enabled = fillCheckToolStripButton.Enabled = b;
            if (!b) fillToolStripMenuItem.Checked = fillCheckToolStripButton.Checked = b;
        }
        private void UpdateFillButtons()
        {
            UpdateFillButtons(IsFillable(currentFigure));
        }

        private void UpdateFigureButtons(FigureType figure)
        {
            rectangleToolStripMenuItem.Checked = rectangleToolStripButton.Checked =
                curveToolStripMenuItem.Checked = curveToolStripButton.Checked =
                ellipseToolStripMenuItem.Checked = ellipseToolStripButton.Checked =
                lineToolStripMenuItem.Checked = lineToolStripButton.Checked =
                textToolStripMenuItem.Checked = textToolStripButton.Checked =
                cursorToolStripMenuItem.Checked = cursorToolStripButton.Checked = false;
            switch (figure)
            {
                case FigureType.Rectangle:
                    rectangleToolStripMenuItem.Checked = rectangleToolStripButton.Checked = true;
                    break;
                case FigureType.Ellipse:
                    ellipseToolStripMenuItem.Checked = ellipseToolStripButton.Checked = true;
                    break;
                case FigureType.Line:
                    lineToolStripMenuItem.Checked = lineToolStripButton.Checked = true;
                    break;
                case FigureType.Curve:
                    curveToolStripMenuItem.Checked = curveToolStripButton.Checked = true;
                    break;
                case FigureType.Text:
                    textToolStripMenuItem.Checked = textToolStripButton.Checked = true;
                    break;
                case FigureType.Cursor:
                    cursorToolStripMenuItem.Checked = cursorToolStripButton.Checked = true;
                    break;
                default:
                    break;
            }
            UpdateFillButtons();
            if (ActiveCanvas != null)
            {
                ActiveCanvas.DeselectAll();
            }
        }

        private bool IsFillable(FigureType figure)
        {
            switch (figure)
            {
                case FigureType.Rectangle:
                case FigureType.Ellipse:
                    return true;
                case FigureType.Line:
                case FigureType.Curve:
                case FigureType.Text:
                case FigureType.Cursor:
                    return false;
                default:
                    throw new Exception("There are no such figure type.");
            }
        }

        /*private void UpdateSelectedFigureStatusBar()
        {
            ShowLineWidth(ActiveCanvas.SelectedFigure.LineWidth);
            ShowLineColor(ActiveCanvas.SelectedFigure.LineColor);
            ShowBackgroundColor(ActiveCanvas.SelectedFigure.BackgroundColor);
        }*/

        private void StatusBar_DrawItem(object sender, StatusBarDrawItemEventArgs sbdevent)
        {
            ShowLineWidth(CurrentLineWidth);
            ShowLineColor(CurrentLineColor);
            ShowBackgroundColor(CurrentBackgroundColor);
            ShowCursorPosition(new Point(0, 0));
            ShowCanvasSize(new Size(0, 0));
        }

        public void ShowLineWidth(int w)
        {
            StatusBar.Panels[0].Text = string.Format("Размер пера: {0}", w);
        }

        public void ShowLineColor(Color c)
        {
            var graphics = StatusBar.CreateGraphics();
            var brush = new SolidBrush(c);
            System.Drawing.Rectangle rectangle = new System.Drawing.Rectangle(
                StatusBar.Panels[0].Width + StatusBar.Panels[1].Width,
                0 + 1,
                StatusBar.Panels[2].Width - 1,
                StatusBar.Height - 1);
            graphics.FillRectangle(brush, rectangle);
        }
        public void ShowBackgroundColor(Color c)
        {
            var graphics = StatusBar.CreateGraphics();
            var brush = new SolidBrush(c);
            System.Drawing.Rectangle rectangle = new System.Drawing.Rectangle(
                StatusBar.Panels[0].Width + StatusBar.Panels[1].Width + StatusBar.Panels[2].Width + StatusBar.Panels[3].Width,
                0 + 1,
                StatusBar.Panels[4].Width - 1,
                StatusBar.Height - 1);
            graphics.FillRectangle(brush, rectangle);
        }

        public void ShowCursorPosition(Point p)
        {
            StatusBar.Panels[5].Text = string.Format("Курсор: X {0} Y {1}", p.X, p.Y);
        }
        public void ShowEmptyCursorPosition()
        {
            StatusBar.Panels[5].Text = string.Format("Курсор: X {0} Y {1}", 0, 0);
        }

        public void ShowCanvasSize(Size s)
        {
            StatusBar.Panels[6].Text = string.Format("Холст: W {0} H {1}", s.Width, s.Height);
        }
        public void ShowCanvasSize()
        {
            var size = ActiveMdiChild == null ? Size.Empty : ActiveCanvas.CanvasSize;
            ShowCanvasSize(size);
        }   

        public void ShowFont(Font f)
        {
            if (currentFigure == FigureType.Text)
            {
                StatusBar.Panels[8].Text = string.Format("{0} {1} пт.", f.Name, f.Size);
                //StatusBar.Panels[8].BorderStyle = StatusBarPanelBorderStyle.Sunken;
            }
            else
            {
                StatusBar.Panels[8].Text = "";
                //StatusBar.Panels[8].BorderStyle = StatusBarPanelBorderStyle.None;
            }
        }

        private void FontChoice_Click(object sender, EventArgs e)
        {
            var fontDialog = new FontDialog();
            if (fontDialog.ShowDialog() == DialogResult.OK)
            {
                if (ActiveCanvas != null && ActiveCanvas.HasSingleSelection)
                {
                    ((OOP.Figures.Text)ActiveCanvas.SelectedFigure).Font = fontDialog.Font;
                    ActiveCanvas.Refresh();
                }
                else
                {
                    CurrentFont = fontDialog.Font;
                }
            }
        }

        private void Text_Click(object sender, EventArgs e)
        {
            CurrentFigure = FigureType.Text;
        }

        private void MainForm_Load(object sender, EventArgs e)
        {

        }

        private void StatusBar_PanelClick(object sender, StatusBarPanelClickEventArgs e)
        {

        }

        private void Cursor_Click(object sender, EventArgs e)
        {
            CurrentFigure = FigureType.Cursor;
        }

        private void Delete_Click(object sender, EventArgs e)
        {
            if (!(ActiveMdiChild == null))
            {
                ActiveCanvas.DeleteSelectedFigures();
            }
        }

        private void MenuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void Copy_Click(object sender, EventArgs e)
        {
            var binaryFormatter = new BinaryFormatter();
            var memoryStream = new MemoryStream();
            var figures = ActiveCanvas.GetSelectedFigures();
            binaryFormatter.Serialize(memoryStream, figures);
            var dataObject = new DataObject();
            dataObject.SetData(formatName, memoryStream);
            Clipboard.SetDataObject(data: dataObject, copy: true);
            memoryStream.Close();
            UpdateEditButtons();
        }

        private void CopyMeta_Click(object sender, EventArgs e)
        {
            var graphics = CreateGraphics();
            var intPtr = graphics.GetHdc();
            var metafile = new Metafile(intPtr, EmfType.EmfOnly);
            graphics.ReleaseHdc(intPtr);
            graphics.Dispose();
            graphics = Graphics.FromImage(metafile);
            var figures = ActiveCanvas.GetSelectedFigures();
            figures.ForEach(
                figure => figure.Draw(graphics, Point.Empty));
            graphics.Dispose();
            OOP.Utility.ClipboardMetafileHelper.PutEnhMetafileOnClipboard(this.Handle, metafile);
            UpdateEditButtons();
        }

        private void Cut_Click(object sender, EventArgs e)
        {
            Copy_Click(sender, e);
            Delete_Click(sender, e);
        }
            
        private void Paste_Click(object sender, EventArgs e)
        {
            ActiveCanvas.DeselectAll();
            var dataObject = Clipboard.GetDataObject();
            var memoryStream = (MemoryStream)dataObject.GetData(formatName);
            var binaryFormatter = new BinaryFormatter();
            var figures = (List<Figure>)binaryFormatter.Deserialize(memoryStream);
            memoryStream.Close();
            var leftTopPosition = new Point(int.MaxValue, int.MaxValue);
            var rightBottomPosition = new Point(int.MinValue, int.MinValue);
            figures.ForEach(figure =>
            {
                leftTopPosition.X = Math.Min(figure.FirstPoint.X, leftTopPosition.X);
                leftTopPosition.Y = Math.Min(figure.FirstPoint.Y, leftTopPosition.Y);
                rightBottomPosition.X = Math.Max(figure.SecondPoint.X, rightBottomPosition.X);
                rightBottomPosition.Y = Math.Max(figure.SecondPoint.Y, rightBottomPosition.Y);
            });

            if (rightBottomPosition.X - leftTopPosition.X > ActiveCanvas.CanvasSize.Width ||
                rightBottomPosition.Y - leftTopPosition.Y > ActiveCanvas.CanvasSize.Height)
            {
                MessageBox.Show(
                    "Изображение в буфере обмена превышает размеры данного холста",
                    "Ошибка выполнения операции");
                return;
            }

            var moveShift = new Point(-leftTopPosition.X, -leftTopPosition.Y);
            figures.ForEach(figure =>
            {
                figure.Move(moveShift);
                figure.Selected = true;
            });
            CurrentFigure = FigureType.Cursor;
            ActiveCanvas.AddFigures(figures);
        }

        private void SelectAll_Click(object sender, EventArgs e)
        {
            CurrentFigure = FigureType.Cursor;
            ActiveCanvas.SelectAll();
        }

        private bool HasBufferedInformation()
        {
            var dataObject = Clipboard.GetDataObject();
            return dataObject != null && dataObject.GetDataPresent(formatName);
        }

        public void UpdateEditButtons()
        {
            fontChoiceToolStripButton.Enabled = fontChoiceToolStripMenuItem.Enabled = true;
            UpdateFillButtons();
            if (ActiveCanvas != null)
            {
                editToolStripButton.Enabled = editToolStripMenuItem.Enabled
                    = alignToGridToolStripButton.Enabled = alignToGridToolStripMenuItem.Enabled
                    = selectAllToolStripButton.Enabled = selectAllToolStripMenuItem.Enabled
                    = true;
                pasteToolStripButton.Enabled = pasteToolStripMenuItem.Enabled
                    = HasBufferedInformation();
                deleteToolStripButton.Enabled = deleteToolStripMenuItem.Enabled
                    = copyToolStripButton.Enabled = copyToolStripMenuItem.Enabled
                    = copyMetaToolStripButton.Enabled = copyMetaToolStripMenuItem.Enabled
                    = cutToolStripButton.Enabled = cutToolStripMenuItem.Enabled
                    = ActiveCanvas.HasSelections;
                if (ActiveCanvas.HasSingleSelection)
                {
                    UpdateFillButtons(IsFillable(ActiveCanvas.SelectedFigure.Type));
                    fillCheckToolStripButton.Checked = fillToolStripMenuItem.Checked = ActiveCanvas.SelectedFigure.Filled;
                    if (ActiveCanvas.SelectedFigure.Type == OOP.Figures.FigureType.Text)
                    {
                        fontChoiceToolStripButton.Enabled = fontChoiceToolStripMenuItem.Enabled = true;
                    }
                    else
                    {
                        fontChoiceToolStripButton.Enabled = fontChoiceToolStripMenuItem.Enabled = false;
                    }
                }
            }
            else
            {
                selectAllToolStripButton.Enabled = selectAllToolStripMenuItem.Enabled
                    = pasteToolStripButton.Enabled = pasteToolStripMenuItem.Enabled
                    = deleteToolStripButton.Enabled = deleteToolStripMenuItem.Enabled
                    = copyToolStripButton.Enabled = copyToolStripMenuItem.Enabled
                    = copyMetaToolStripButton.Enabled = copyMetaToolStripMenuItem.Enabled
                    = cutToolStripButton.Enabled = cutToolStripMenuItem.Enabled
                    = editToolStripButton.Enabled = editToolStripMenuItem.Enabled
                    = alignToGridToolStripButton.Enabled = alignToGridToolStripMenuItem.Enabled
                    = false;
            }
        }

        public void ShowGridPitch()
        {
            StatusBar.Panels[7].Text = string.Format("Шаг сетки: {0}", gridPitch);
        }

        private void AlignToGrid_Click(object sender, EventArgs e)
        {
            ActiveCanvas.AlignFigures();
            ActiveCanvas.Refresh();
        }

        private void Grid_Click(object sender, EventArgs e)
        {
            showGrid = gridToolStripButton.Checked = gridToolStripMenuItem.Checked = !showGrid;
            UpdatePaintForms();
        }

        private void GridPitch_Click(object sender, EventArgs e)
        {
            var gridPitchDialog = new GridPitchDialog(gridPitch);
            if (gridPitchDialog.ShowDialog() == DialogResult.OK)
            {
                gridPitch = gridPitchDialog.pitch;
            }
            ShowGridPitch();
            UpdatePaintForms();
        }

        private void SnapToGrid_Click(object sender, EventArgs e)
        {
            snapToGrid = snapToGridToolStripButton.Checked = snapToGridToolStripMenuItem.Checked = !snapToGrid;
            UpdatePaintForms();
        }

        private void UpdatePaintForms()
        {
            foreach (PaintForm paintForm in MdiChildren)
            {
                paintForm.Refresh();
            }
        }

        private void attributesToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void Edit_Click(object sender, EventArgs e)
        {
            var editForm = new OOP.Forms.EditForm(ActiveCanvas);
            editForm.ShowDialog();
        }
    }
}
