﻿namespace OOP.Forms
{
    partial class SizeDialog
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SizeDialog));
            this.SizeChoiceGroupBox = new System.Windows.Forms.GroupBox();
            this.SizeRadio3 = new System.Windows.Forms.RadioButton();
            this.SizeRadio2 = new System.Windows.Forms.RadioButton();
            this.SizeRadio1 = new System.Windows.Forms.RadioButton();
            this.CustomSizeCheckBox = new System.Windows.Forms.CheckBox();
            this.WidthLabel = new System.Windows.Forms.Label();
            this.HeightLabel = new System.Windows.Forms.Label();
            this.WidthTextBox = new System.Windows.Forms.TextBox();
            this.HeightTextBox = new System.Windows.Forms.TextBox();
            this.OKButton = new System.Windows.Forms.Button();
            this.ButtonCancel = new System.Windows.Forms.Button();
            this.SizeChoiceGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // SizeChoiceGroupBox
            // 
            this.SizeChoiceGroupBox.Controls.Add(this.SizeRadio3);
            this.SizeChoiceGroupBox.Controls.Add(this.SizeRadio2);
            this.SizeChoiceGroupBox.Controls.Add(this.SizeRadio1);
            this.SizeChoiceGroupBox.Location = new System.Drawing.Point(13, 13);
            this.SizeChoiceGroupBox.Name = "SizeChoiceGroupBox";
            this.SizeChoiceGroupBox.Size = new System.Drawing.Size(164, 91);
            this.SizeChoiceGroupBox.TabIndex = 0;
            this.SizeChoiceGroupBox.TabStop = false;
            this.SizeChoiceGroupBox.Text = "Рекомендуемый размер";
            this.SizeChoiceGroupBox.Enter += new System.EventHandler(this.SizeChoiceGroupBox_Enter);
            // 
            // SizeRadio3
            // 
            this.SizeRadio3.AutoSize = true;
            this.SizeRadio3.Location = new System.Drawing.Point(7, 68);
            this.SizeRadio3.Name = "SizeRadio3";
            this.SizeRadio3.Size = new System.Drawing.Size(72, 17);
            this.SizeRadio3.TabIndex = 2;
            this.SizeRadio3.Text = "800 х 600";
            this.SizeRadio3.UseVisualStyleBackColor = true;
            this.SizeRadio3.CheckedChanged += new System.EventHandler(this.SizeRadio3_CheckedChanged);
            // 
            // SizeRadio2
            // 
            this.SizeRadio2.AutoSize = true;
            this.SizeRadio2.Location = new System.Drawing.Point(7, 44);
            this.SizeRadio2.Name = "SizeRadio2";
            this.SizeRadio2.Size = new System.Drawing.Size(72, 17);
            this.SizeRadio2.TabIndex = 1;
            this.SizeRadio2.Text = "640 х 480";
            this.SizeRadio2.UseVisualStyleBackColor = true;
            this.SizeRadio2.CheckedChanged += new System.EventHandler(this.SizeRadio2_CheckedChanged);
            // 
            // SizeRadio1
            // 
            this.SizeRadio1.AutoSize = true;
            this.SizeRadio1.Checked = true;
            this.SizeRadio1.Location = new System.Drawing.Point(7, 20);
            this.SizeRadio1.Name = "SizeRadio1";
            this.SizeRadio1.Size = new System.Drawing.Size(72, 17);
            this.SizeRadio1.TabIndex = 0;
            this.SizeRadio1.TabStop = true;
            this.SizeRadio1.Text = "320 х 240";
            this.SizeRadio1.UseVisualStyleBackColor = true;
            this.SizeRadio1.CheckedChanged += new System.EventHandler(this.SizeRadio1_CheckedChanged);
            // 
            // CustomSizeCheckBox
            // 
            this.CustomSizeCheckBox.AutoSize = true;
            this.CustomSizeCheckBox.Location = new System.Drawing.Point(13, 110);
            this.CustomSizeCheckBox.Name = "CustomSizeCheckBox";
            this.CustomSizeCheckBox.Size = new System.Drawing.Size(164, 17);
            this.CustomSizeCheckBox.TabIndex = 1;
            this.CustomSizeCheckBox.Text = "Пользовательский размер";
            this.CustomSizeCheckBox.UseVisualStyleBackColor = true;
            this.CustomSizeCheckBox.CheckedChanged += new System.EventHandler(this.CustomSizeCheckBox_CheckedChanged);
            // 
            // WidthLabel
            // 
            this.WidthLabel.AutoSize = true;
            this.WidthLabel.Location = new System.Drawing.Point(12, 136);
            this.WidthLabel.Name = "WidthLabel";
            this.WidthLabel.Size = new System.Drawing.Size(49, 13);
            this.WidthLabel.TabIndex = 2;
            this.WidthLabel.Text = "Ширина:";
            // 
            // HeightLabel
            // 
            this.HeightLabel.AutoSize = true;
            this.HeightLabel.Location = new System.Drawing.Point(12, 162);
            this.HeightLabel.Name = "HeightLabel";
            this.HeightLabel.Size = new System.Drawing.Size(48, 13);
            this.HeightLabel.TabIndex = 3;
            this.HeightLabel.Text = "Высота:";
            // 
            // WidthTextBox
            // 
            this.WidthTextBox.Enabled = false;
            this.WidthTextBox.Location = new System.Drawing.Point(66, 133);
            this.WidthTextBox.Name = "WidthTextBox";
            this.WidthTextBox.Size = new System.Drawing.Size(111, 20);
            this.WidthTextBox.TabIndex = 4;
            this.WidthTextBox.Text = "320";
            this.WidthTextBox.TextChanged += new System.EventHandler(this.WidthTextBox_TextChanged);
            // 
            // HeightTextBox
            // 
            this.HeightTextBox.Enabled = false;
            this.HeightTextBox.Location = new System.Drawing.Point(66, 159);
            this.HeightTextBox.Name = "HeightTextBox";
            this.HeightTextBox.Size = new System.Drawing.Size(111, 20);
            this.HeightTextBox.TabIndex = 4;
            this.HeightTextBox.Text = "240";
            this.HeightTextBox.TextChanged += new System.EventHandler(this.HeightTextBox_TextChanged);
            // 
            // OKButton
            // 
            this.OKButton.Location = new System.Drawing.Point(12, 185);
            this.OKButton.Name = "OKButton";
            this.OKButton.Size = new System.Drawing.Size(75, 23);
            this.OKButton.TabIndex = 5;
            this.OKButton.Text = "ОК";
            this.OKButton.UseVisualStyleBackColor = true;
            this.OKButton.Click += new System.EventHandler(this.OKButton_Click);
            // 
            // ButtonCancel
            // 
            this.ButtonCancel.Location = new System.Drawing.Point(102, 185);
            this.ButtonCancel.Name = "ButtonCancel";
            this.ButtonCancel.Size = new System.Drawing.Size(75, 23);
            this.ButtonCancel.TabIndex = 6;
            this.ButtonCancel.Text = "Отмена";
            this.ButtonCancel.UseVisualStyleBackColor = true;
            this.ButtonCancel.Click += new System.EventHandler(this.CancelButton_Click);
            // 
            // SizeDialog
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(190, 221);
            this.Controls.Add(this.ButtonCancel);
            this.Controls.Add(this.OKButton);
            this.Controls.Add(this.HeightTextBox);
            this.Controls.Add(this.WidthTextBox);
            this.Controls.Add(this.HeightLabel);
            this.Controls.Add(this.WidthLabel);
            this.Controls.Add(this.CustomSizeCheckBox);
            this.Controls.Add(this.SizeChoiceGroupBox);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "SizeDialog";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Размер холста";
            this.Load += new System.EventHandler(this.SizeDialog_Load);
            this.SizeChoiceGroupBox.ResumeLayout(false);
            this.SizeChoiceGroupBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox SizeChoiceGroupBox;
        private System.Windows.Forms.RadioButton SizeRadio3;
        private System.Windows.Forms.RadioButton SizeRadio2;
        private System.Windows.Forms.RadioButton SizeRadio1;
        private System.Windows.Forms.CheckBox CustomSizeCheckBox;
        private System.Windows.Forms.Label WidthLabel;
        private System.Windows.Forms.Label HeightLabel;
        private System.Windows.Forms.TextBox WidthTextBox;
        private System.Windows.Forms.TextBox HeightTextBox;
        private System.Windows.Forms.Button OKButton;
        private System.Windows.Forms.Button ButtonCancel;
    }
}