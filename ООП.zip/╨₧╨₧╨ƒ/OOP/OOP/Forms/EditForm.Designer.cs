﻿namespace OOP.Forms
{
    partial class EditForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.figuresListView = new System.Windows.Forms.ListView();
            this.columnElementNumber = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnFigureType = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnFirstPointCoordinates = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.flowLayoutPanel = new System.Windows.Forms.FlowLayoutPanel();
            this.addButton = new System.Windows.Forms.Button();
            this.deleteButton = new System.Windows.Forms.Button();
            this.saveButton = new System.Windows.Forms.Button();
            this.closeButton = new System.Windows.Forms.Button();
            this.toUpButton = new System.Windows.Forms.Button();
            this.toBottomButton = new System.Windows.Forms.Button();
            this.toStartButton = new System.Windows.Forms.Button();
            this.toBackButton = new System.Windows.Forms.Button();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.SuspendLayout();
            // 
            // figuresListView
            // 
            this.figuresListView.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnElementNumber,
            this.columnFigureType,
            this.columnFirstPointCoordinates});
            this.figuresListView.FullRowSelect = true;
            this.figuresListView.HideSelection = false;
            this.figuresListView.Location = new System.Drawing.Point(12, 12);
            this.figuresListView.MultiSelect = false;
            this.figuresListView.Name = "figuresListView";
            this.figuresListView.Size = new System.Drawing.Size(255, 337);
            this.figuresListView.TabIndex = 0;
            this.figuresListView.UseCompatibleStateImageBehavior = false;
            this.figuresListView.View = System.Windows.Forms.View.Details;
            this.figuresListView.SelectedIndexChanged += new System.EventHandler(this.FiguresListView_SelectedIndexChanged);
            // 
            // columnElementNumber
            // 
            this.columnElementNumber.Text = "Номер";
            this.columnElementNumber.Width = 50;
            // 
            // columnFigureType
            // 
            this.columnFigureType.Text = "Тип фигуры";
            this.columnFigureType.Width = 100;
            // 
            // columnFirstPointCoordinates
            // 
            this.columnFirstPointCoordinates.Text = "Расположение";
            this.columnFirstPointCoordinates.Width = 100;
            // 
            // flowLayoutPanel
            // 
            this.flowLayoutPanel.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flowLayoutPanel.Location = new System.Drawing.Point(274, 12);
            this.flowLayoutPanel.Name = "flowLayoutPanel";
            this.flowLayoutPanel.Size = new System.Drawing.Size(298, 265);
            this.flowLayoutPanel.TabIndex = 1;
            // 
            // addButton
            // 
            this.addButton.Location = new System.Drawing.Point(426, 283);
            this.addButton.Name = "addButton";
            this.addButton.Size = new System.Drawing.Size(70, 30);
            this.addButton.TabIndex = 0;
            this.addButton.Text = "Добавить";
            this.addButton.UseVisualStyleBackColor = true;
            this.addButton.Click += new System.EventHandler(this.AddButton_Click);
            // 
            // deleteButton
            // 
            this.deleteButton.Enabled = false;
            this.deleteButton.Location = new System.Drawing.Point(426, 319);
            this.deleteButton.Name = "deleteButton";
            this.deleteButton.Size = new System.Drawing.Size(70, 30);
            this.deleteButton.TabIndex = 0;
            this.deleteButton.Text = "Удалить";
            this.deleteButton.UseVisualStyleBackColor = true;
            this.deleteButton.Click += new System.EventHandler(this.DeleteButton_Click);
            // 
            // saveButton
            // 
            this.saveButton.Enabled = false;
            this.saveButton.Location = new System.Drawing.Point(502, 283);
            this.saveButton.Name = "saveButton";
            this.saveButton.Size = new System.Drawing.Size(70, 30);
            this.saveButton.TabIndex = 0;
            this.saveButton.Text = "Сохранить";
            this.saveButton.UseVisualStyleBackColor = true;
            this.saveButton.Click += new System.EventHandler(this.SaveButton_Click);
            // 
            // closeButton
            // 
            this.closeButton.Location = new System.Drawing.Point(502, 319);
            this.closeButton.Name = "closeButton";
            this.closeButton.Size = new System.Drawing.Size(70, 30);
            this.closeButton.TabIndex = 0;
            this.closeButton.Text = "Закрыть";
            this.closeButton.UseVisualStyleBackColor = true;
            this.closeButton.Click += new System.EventHandler(this.CloseButton_Click);
            // 
            // toUpButton
            // 
            this.toUpButton.Enabled = false;
            this.toUpButton.Location = new System.Drawing.Point(274, 283);
            this.toUpButton.Name = "toUpButton";
            this.toUpButton.Size = new System.Drawing.Size(70, 30);
            this.toUpButton.TabIndex = 0;
            this.toUpButton.Text = "Вверх";
            this.toUpButton.UseVisualStyleBackColor = true;
            this.toUpButton.Click += new System.EventHandler(this.ToUpButton_Click);
            // 
            // toBottomButton
            // 
            this.toBottomButton.Enabled = false;
            this.toBottomButton.Location = new System.Drawing.Point(274, 319);
            this.toBottomButton.Name = "toBottomButton";
            this.toBottomButton.Size = new System.Drawing.Size(70, 30);
            this.toBottomButton.TabIndex = 0;
            this.toBottomButton.Text = "Вниз";
            this.toBottomButton.UseVisualStyleBackColor = true;
            this.toBottomButton.Click += new System.EventHandler(this.ToBottomButton_Click);
            // 
            // toStartButton
            // 
            this.toStartButton.Enabled = false;
            this.toStartButton.Location = new System.Drawing.Point(350, 283);
            this.toStartButton.Name = "toStartButton";
            this.toStartButton.Size = new System.Drawing.Size(70, 30);
            this.toStartButton.TabIndex = 0;
            this.toStartButton.Text = "В начало";
            this.toStartButton.UseVisualStyleBackColor = true;
            this.toStartButton.Click += new System.EventHandler(this.ToStartButton_Click);
            // 
            // toBackButton
            // 
            this.toBackButton.Enabled = false;
            this.toBackButton.Location = new System.Drawing.Point(350, 319);
            this.toBackButton.Name = "toBackButton";
            this.toBackButton.Size = new System.Drawing.Size(70, 30);
            this.toBackButton.TabIndex = 0;
            this.toBackButton.Text = "В конец";
            this.toBackButton.UseVisualStyleBackColor = true;
            this.toBackButton.Click += new System.EventHandler(this.ToBackButton_Click);
            // 
            // EditForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(584, 361);
            this.Controls.Add(this.closeButton);
            this.Controls.Add(this.saveButton);
            this.Controls.Add(this.deleteButton);
            this.Controls.Add(this.toBackButton);
            this.Controls.Add(this.toStartButton);
            this.Controls.Add(this.toBottomButton);
            this.Controls.Add(this.toUpButton);
            this.Controls.Add(this.addButton);
            this.Controls.Add(this.flowLayoutPanel);
            this.Controls.Add(this.figuresListView);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Name = "EditForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Редактирование";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListView figuresListView;
        private System.Windows.Forms.ColumnHeader columnElementNumber;
        private System.Windows.Forms.ColumnHeader columnFigureType;
        private System.Windows.Forms.ColumnHeader columnFirstPointCoordinates;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel;
        private System.Windows.Forms.Button addButton;
        private System.Windows.Forms.Button deleteButton;
        private System.Windows.Forms.Button saveButton;
        private System.Windows.Forms.Button closeButton;
        private System.Windows.Forms.Button toUpButton;
        private System.Windows.Forms.Button toBottomButton;
        private System.Windows.Forms.Button toStartButton;
        private System.Windows.Forms.Button toBackButton;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
    }
}