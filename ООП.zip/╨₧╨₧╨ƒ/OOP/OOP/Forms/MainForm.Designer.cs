﻿namespace OOP
{
    partial class MainForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.projectToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.newToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveAsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.resizeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.окноToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.parametersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lineColorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.backgroundColorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lineWidthToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fontChoiceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.правкаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.copyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.copyMetaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pasteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.selectAllToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.alignToGridToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.figureToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cursorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rectangleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ellipseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lineToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.curveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.textToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fillToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.attributesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gridToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gridPitchToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.snapToGridToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.StatusBar = new System.Windows.Forms.StatusBar();
            this.WidthStatusBarPanel = new System.Windows.Forms.StatusBarPanel();
            this.ColorStatusBarPanel = new System.Windows.Forms.StatusBarPanel();
            this.ColorDrawStatusBarPanel = new System.Windows.Forms.StatusBarPanel();
            this.FillStatusBarPanel = new System.Windows.Forms.StatusBarPanel();
            this.FillDrawStatusBarPanel = new System.Windows.Forms.StatusBarPanel();
            this.CursorStatusBarPanel = new System.Windows.Forms.StatusBarPanel();
            this.CanvasSizeStatusBarPanel = new System.Windows.Forms.StatusBarPanel();
            this.GridPitchStatusBarPanel = new System.Windows.Forms.StatusBarPanel();
            this.TextStatusPanel = new System.Windows.Forms.StatusBarPanel();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.saveToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.saveAsToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.resizeToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.lineColorToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.lineWidthToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.backgroundColorToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.fontChoiceToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.deleteToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.copyToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.copyMetaToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.cutToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.pasteToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.selectAllToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.alignToGridToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.cursorToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.rectangleToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.ellipseToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.lineToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.curveToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.textToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.fillCheckToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.gridToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.gridPitchToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.snapToGridToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.editToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.WidthStatusBarPanel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ColorStatusBarPanel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ColorDrawStatusBarPanel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.FillStatusBarPanel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.FillDrawStatusBarPanel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.CursorStatusBarPanel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.CanvasSizeStatusBarPanel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GridPitchStatusBarPanel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TextStatusPanel)).BeginInit();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.projectToolStripMenuItem,
            this.окноToolStripMenuItem,
            this.parametersToolStripMenuItem,
            this.правкаToolStripMenuItem,
            this.figureToolStripMenuItem,
            this.attributesToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1008, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.MenuStrip1_ItemClicked);
            // 
            // projectToolStripMenuItem
            // 
            this.projectToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newToolStripMenuItem,
            this.openToolStripMenuItem,
            this.saveToolStripMenuItem,
            this.saveAsToolStripMenuItem,
            this.resizeToolStripMenuItem});
            this.projectToolStripMenuItem.Name = "projectToolStripMenuItem";
            this.projectToolStripMenuItem.Size = new System.Drawing.Size(48, 20);
            this.projectToolStripMenuItem.Text = "Файл";
            this.projectToolStripMenuItem.Click += new System.EventHandler(this.ProjectToolStripMenuItem_Click);
            // 
            // newToolStripMenuItem
            // 
            this.newToolStripMenuItem.Name = "newToolStripMenuItem";
            this.newToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.N)));
            this.newToolStripMenuItem.Size = new System.Drawing.Size(235, 22);
            this.newToolStripMenuItem.Text = "Новый";
            this.newToolStripMenuItem.Click += new System.EventHandler(this.New_Click);
            // 
            // openToolStripMenuItem
            // 
            this.openToolStripMenuItem.Name = "openToolStripMenuItem";
            this.openToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.O)));
            this.openToolStripMenuItem.Size = new System.Drawing.Size(235, 22);
            this.openToolStripMenuItem.Text = "Открыть";
            this.openToolStripMenuItem.Click += new System.EventHandler(this.Open_Click);
            // 
            // saveToolStripMenuItem
            // 
            this.saveToolStripMenuItem.Enabled = false;
            this.saveToolStripMenuItem.Name = "saveToolStripMenuItem";
            this.saveToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.S)));
            this.saveToolStripMenuItem.Size = new System.Drawing.Size(235, 22);
            this.saveToolStripMenuItem.Text = "Сохранить";
            this.saveToolStripMenuItem.Click += new System.EventHandler(this.Save_Click);
            // 
            // saveAsToolStripMenuItem
            // 
            this.saveAsToolStripMenuItem.Enabled = false;
            this.saveAsToolStripMenuItem.Name = "saveAsToolStripMenuItem";
            this.saveAsToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)(((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Shift) 
            | System.Windows.Forms.Keys.S)));
            this.saveAsToolStripMenuItem.Size = new System.Drawing.Size(235, 22);
            this.saveAsToolStripMenuItem.Text = "Сохранить как...";
            this.saveAsToolStripMenuItem.Click += new System.EventHandler(this.SaveAs_Click);
            // 
            // resizeToolStripMenuItem
            // 
            this.resizeToolStripMenuItem.Name = "resizeToolStripMenuItem";
            this.resizeToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.W)));
            this.resizeToolStripMenuItem.Size = new System.Drawing.Size(235, 22);
            this.resizeToolStripMenuItem.Text = "Выбор размера";
            this.resizeToolStripMenuItem.Click += new System.EventHandler(this.CanvasSize_Click);
            // 
            // окноToolStripMenuItem
            // 
            this.окноToolStripMenuItem.Name = "окноToolStripMenuItem";
            this.окноToolStripMenuItem.Size = new System.Drawing.Size(48, 20);
            this.окноToolStripMenuItem.Text = "Окно";
            // 
            // parametersToolStripMenuItem
            // 
            this.parametersToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lineColorToolStripMenuItem,
            this.backgroundColorToolStripMenuItem,
            this.lineWidthToolStripMenuItem,
            this.fontChoiceToolStripMenuItem,
            this.deleteToolStripMenuItem});
            this.parametersToolStripMenuItem.Name = "parametersToolStripMenuItem";
            this.parametersToolStripMenuItem.Size = new System.Drawing.Size(83, 20);
            this.parametersToolStripMenuItem.Text = "Параметры";
            // 
            // lineColorToolStripMenuItem
            // 
            this.lineColorToolStripMenuItem.Name = "lineColorToolStripMenuItem";
            this.lineColorToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.C)));
            this.lineColorToolStripMenuItem.Size = new System.Drawing.Size(204, 22);
            this.lineColorToolStripMenuItem.Text = "Цвет линии";
            this.lineColorToolStripMenuItem.Click += new System.EventHandler(this.LineColor_Click);
            // 
            // backgroundColorToolStripMenuItem
            // 
            this.backgroundColorToolStripMenuItem.Name = "backgroundColorToolStripMenuItem";
            this.backgroundColorToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.B)));
            this.backgroundColorToolStripMenuItem.Size = new System.Drawing.Size(204, 22);
            this.backgroundColorToolStripMenuItem.Text = "Цвет заливки";
            this.backgroundColorToolStripMenuItem.Click += new System.EventHandler(this.FillColor_Click);
            // 
            // lineWidthToolStripMenuItem
            // 
            this.lineWidthToolStripMenuItem.Name = "lineWidthToolStripMenuItem";
            this.lineWidthToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.W)));
            this.lineWidthToolStripMenuItem.Size = new System.Drawing.Size(204, 22);
            this.lineWidthToolStripMenuItem.Text = "Толщина линии";
            this.lineWidthToolStripMenuItem.Click += new System.EventHandler(this.LineWidth_Click);
            // 
            // fontChoiceToolStripMenuItem
            // 
            this.fontChoiceToolStripMenuItem.Name = "fontChoiceToolStripMenuItem";
            this.fontChoiceToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.F)));
            this.fontChoiceToolStripMenuItem.Size = new System.Drawing.Size(204, 22);
            this.fontChoiceToolStripMenuItem.Text = "Выбор шрифта";
            this.fontChoiceToolStripMenuItem.Click += new System.EventHandler(this.FontChoice_Click);
            // 
            // deleteToolStripMenuItem
            // 
            this.deleteToolStripMenuItem.Name = "deleteToolStripMenuItem";
            this.deleteToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.Delete;
            this.deleteToolStripMenuItem.Size = new System.Drawing.Size(204, 22);
            this.deleteToolStripMenuItem.Text = "Удалить";
            this.deleteToolStripMenuItem.Click += new System.EventHandler(this.Delete_Click);
            // 
            // правкаToolStripMenuItem
            // 
            this.правкаToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.copyToolStripMenuItem,
            this.copyMetaToolStripMenuItem,
            this.cutToolStripMenuItem,
            this.pasteToolStripMenuItem,
            this.selectAllToolStripMenuItem,
            this.alignToGridToolStripMenuItem,
            this.editToolStripMenuItem});
            this.правкаToolStripMenuItem.Name = "правкаToolStripMenuItem";
            this.правкаToolStripMenuItem.Size = new System.Drawing.Size(59, 20);
            this.правкаToolStripMenuItem.Text = "Правка";
            // 
            // copyToolStripMenuItem
            // 
            this.copyToolStripMenuItem.Name = "copyToolStripMenuItem";
            this.copyToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.C)));
            this.copyToolStripMenuItem.Size = new System.Drawing.Size(279, 22);
            this.copyToolStripMenuItem.Text = "Копировать";
            this.copyToolStripMenuItem.Click += new System.EventHandler(this.Copy_Click);
            // 
            // copyMetaToolStripMenuItem
            // 
            this.copyMetaToolStripMenuItem.Name = "copyMetaToolStripMenuItem";
            this.copyMetaToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)(((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Shift) 
            | System.Windows.Forms.Keys.C)));
            this.copyMetaToolStripMenuItem.Size = new System.Drawing.Size(279, 22);
            this.copyMetaToolStripMenuItem.Text = "Копировать (метафайл)";
            this.copyMetaToolStripMenuItem.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.copyMetaToolStripMenuItem.Click += new System.EventHandler(this.CopyMeta_Click);
            // 
            // cutToolStripMenuItem
            // 
            this.cutToolStripMenuItem.Name = "cutToolStripMenuItem";
            this.cutToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.X)));
            this.cutToolStripMenuItem.Size = new System.Drawing.Size(279, 22);
            this.cutToolStripMenuItem.Text = "Вырезать";
            this.cutToolStripMenuItem.Click += new System.EventHandler(this.Cut_Click);
            // 
            // pasteToolStripMenuItem
            // 
            this.pasteToolStripMenuItem.Name = "pasteToolStripMenuItem";
            this.pasteToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.V)));
            this.pasteToolStripMenuItem.Size = new System.Drawing.Size(279, 22);
            this.pasteToolStripMenuItem.Text = "Вставить";
            this.pasteToolStripMenuItem.Click += new System.EventHandler(this.Paste_Click);
            // 
            // selectAllToolStripMenuItem
            // 
            this.selectAllToolStripMenuItem.Name = "selectAllToolStripMenuItem";
            this.selectAllToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.A)));
            this.selectAllToolStripMenuItem.Size = new System.Drawing.Size(279, 22);
            this.selectAllToolStripMenuItem.Text = "Выбрать всё";
            this.selectAllToolStripMenuItem.Click += new System.EventHandler(this.SelectAll_Click);
            // 
            // alignToGridToolStripMenuItem
            // 
            this.alignToGridToolStripMenuItem.Name = "alignToGridToolStripMenuItem";
            this.alignToGridToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)(((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Shift) 
            | System.Windows.Forms.Keys.G)));
            this.alignToGridToolStripMenuItem.Size = new System.Drawing.Size(279, 22);
            this.alignToGridToolStripMenuItem.Text = "Выровнять по сетке";
            this.alignToGridToolStripMenuItem.Click += new System.EventHandler(this.AlignToGrid_Click);
            // 
            // editToolStripMenuItem
            // 
            this.editToolStripMenuItem.Name = "editToolStripMenuItem";
            this.editToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.E)));
            this.editToolStripMenuItem.Size = new System.Drawing.Size(279, 22);
            this.editToolStripMenuItem.Text = "Редактировать";
            this.editToolStripMenuItem.Click += new System.EventHandler(this.Edit_Click);
            // 
            // figureToolStripMenuItem
            // 
            this.figureToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cursorToolStripMenuItem,
            this.rectangleToolStripMenuItem,
            this.ellipseToolStripMenuItem,
            this.lineToolStripMenuItem,
            this.curveToolStripMenuItem,
            this.textToolStripMenuItem,
            this.fillToolStripMenuItem});
            this.figureToolStripMenuItem.Name = "figureToolStripMenuItem";
            this.figureToolStripMenuItem.Size = new System.Drawing.Size(59, 20);
            this.figureToolStripMenuItem.Text = "Фигура";
            // 
            // cursorToolStripMenuItem
            // 
            this.cursorToolStripMenuItem.Name = "cursorToolStripMenuItem";
            this.cursorToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)(((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.Shift) 
            | System.Windows.Forms.Keys.S)));
            this.cursorToolStripMenuItem.Size = new System.Drawing.Size(232, 22);
            this.cursorToolStripMenuItem.Text = "Курсор";
            this.cursorToolStripMenuItem.Click += new System.EventHandler(this.Cursor_Click);
            // 
            // rectangleToolStripMenuItem
            // 
            this.rectangleToolStripMenuItem.Checked = true;
            this.rectangleToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.rectangleToolStripMenuItem.Name = "rectangleToolStripMenuItem";
            this.rectangleToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)(((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.Shift) 
            | System.Windows.Forms.Keys.R)));
            this.rectangleToolStripMenuItem.Size = new System.Drawing.Size(232, 22);
            this.rectangleToolStripMenuItem.Text = "Прямоугольник";
            this.rectangleToolStripMenuItem.Click += new System.EventHandler(this.Rectangle_Click);
            // 
            // ellipseToolStripMenuItem
            // 
            this.ellipseToolStripMenuItem.Name = "ellipseToolStripMenuItem";
            this.ellipseToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)(((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.Shift) 
            | System.Windows.Forms.Keys.E)));
            this.ellipseToolStripMenuItem.Size = new System.Drawing.Size(232, 22);
            this.ellipseToolStripMenuItem.Text = "Эллипс";
            this.ellipseToolStripMenuItem.Click += new System.EventHandler(this.Ellipse_Click);
            // 
            // lineToolStripMenuItem
            // 
            this.lineToolStripMenuItem.Name = "lineToolStripMenuItem";
            this.lineToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)(((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.Shift) 
            | System.Windows.Forms.Keys.L)));
            this.lineToolStripMenuItem.Size = new System.Drawing.Size(232, 22);
            this.lineToolStripMenuItem.Text = "Прямая линия";
            this.lineToolStripMenuItem.Click += new System.EventHandler(this.Line_Click);
            // 
            // curveToolStripMenuItem
            // 
            this.curveToolStripMenuItem.Name = "curveToolStripMenuItem";
            this.curveToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)(((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.Shift) 
            | System.Windows.Forms.Keys.C)));
            this.curveToolStripMenuItem.Size = new System.Drawing.Size(232, 22);
            this.curveToolStripMenuItem.Text = "Кривая линия";
            this.curveToolStripMenuItem.Click += new System.EventHandler(this.Curve_Click);
            // 
            // textToolStripMenuItem
            // 
            this.textToolStripMenuItem.Name = "textToolStripMenuItem";
            this.textToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)(((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.Shift) 
            | System.Windows.Forms.Keys.T)));
            this.textToolStripMenuItem.Size = new System.Drawing.Size(232, 22);
            this.textToolStripMenuItem.Text = "Текст";
            this.textToolStripMenuItem.Click += new System.EventHandler(this.Text_Click);
            // 
            // fillToolStripMenuItem
            // 
            this.fillToolStripMenuItem.Checked = true;
            this.fillToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.fillToolStripMenuItem.Name = "fillToolStripMenuItem";
            this.fillToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.B)));
            this.fillToolStripMenuItem.Size = new System.Drawing.Size(232, 22);
            this.fillToolStripMenuItem.Text = "Заливка";
            this.fillToolStripMenuItem.Click += new System.EventHandler(this.FillCheck_Click);
            // 
            // attributesToolStripMenuItem
            // 
            this.attributesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.gridToolStripMenuItem,
            this.gridPitchToolStripMenuItem,
            this.snapToGridToolStripMenuItem});
            this.attributesToolStripMenuItem.Name = "attributesToolStripMenuItem";
            this.attributesToolStripMenuItem.Size = new System.Drawing.Size(73, 20);
            this.attributesToolStripMenuItem.Text = "Атрибуты";
            this.attributesToolStripMenuItem.Click += new System.EventHandler(this.attributesToolStripMenuItem_Click);
            // 
            // gridToolStripMenuItem
            // 
            this.gridToolStripMenuItem.Name = "gridToolStripMenuItem";
            this.gridToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.G)));
            this.gridToolStripMenuItem.Size = new System.Drawing.Size(205, 22);
            this.gridToolStripMenuItem.Text = "Сетка";
            this.gridToolStripMenuItem.Click += new System.EventHandler(this.Grid_Click);
            // 
            // gridPitchToolStripMenuItem
            // 
            this.gridPitchToolStripMenuItem.Name = "gridPitchToolStripMenuItem";
            this.gridPitchToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)(((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Alt) 
            | System.Windows.Forms.Keys.G)));
            this.gridPitchToolStripMenuItem.Size = new System.Drawing.Size(205, 22);
            this.gridPitchToolStripMenuItem.Text = "Шаг сетки";
            this.gridPitchToolStripMenuItem.Click += new System.EventHandler(this.GridPitch_Click);
            // 
            // snapToGridToolStripMenuItem
            // 
            this.snapToGridToolStripMenuItem.Name = "snapToGridToolStripMenuItem";
            this.snapToGridToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.G)));
            this.snapToGridToolStripMenuItem.Size = new System.Drawing.Size(205, 22);
            this.snapToGridToolStripMenuItem.Text = "Привязка к сетке";
            this.snapToGridToolStripMenuItem.Click += new System.EventHandler(this.SnapToGrid_Click);
            // 
            // StatusBar
            // 
            this.StatusBar.Location = new System.Drawing.Point(0, 707);
            this.StatusBar.Name = "StatusBar";
            this.StatusBar.Panels.AddRange(new System.Windows.Forms.StatusBarPanel[] {
            this.WidthStatusBarPanel,
            this.ColorStatusBarPanel,
            this.ColorDrawStatusBarPanel,
            this.FillStatusBarPanel,
            this.FillDrawStatusBarPanel,
            this.CursorStatusBarPanel,
            this.CanvasSizeStatusBarPanel,
            this.GridPitchStatusBarPanel,
            this.TextStatusPanel});
            this.StatusBar.ShowPanels = true;
            this.StatusBar.Size = new System.Drawing.Size(1008, 22);
            this.StatusBar.TabIndex = 4;
            this.StatusBar.Text = "statusBar1";
            this.StatusBar.DrawItem += new System.Windows.Forms.StatusBarDrawItemEventHandler(this.StatusBar_DrawItem);
            this.StatusBar.PanelClick += new System.Windows.Forms.StatusBarPanelClickEventHandler(this.StatusBar_PanelClick);
            // 
            // WidthStatusBarPanel
            // 
            this.WidthStatusBarPanel.Name = "WidthStatusBarPanel";
            this.WidthStatusBarPanel.Text = "Размер пера: 3";
            this.WidthStatusBarPanel.Width = 99;
            // 
            // ColorStatusBarPanel
            // 
            this.ColorStatusBarPanel.Alignment = System.Windows.Forms.HorizontalAlignment.Right;
            this.ColorStatusBarPanel.BorderStyle = System.Windows.Forms.StatusBarPanelBorderStyle.None;
            this.ColorStatusBarPanel.Name = "ColorStatusBarPanel";
            this.ColorStatusBarPanel.Text = "Цвет пера: ";
            this.ColorStatusBarPanel.Width = 70;
            // 
            // ColorDrawStatusBarPanel
            // 
            this.ColorDrawStatusBarPanel.Name = "ColorDrawStatusBarPanel";
            this.ColorDrawStatusBarPanel.Style = System.Windows.Forms.StatusBarPanelStyle.OwnerDraw;
            this.ColorDrawStatusBarPanel.Text = "Цвет";
            this.ColorDrawStatusBarPanel.ToolTipText = "Цвет пера";
            this.ColorDrawStatusBarPanel.Width = 22;
            // 
            // FillStatusBarPanel
            // 
            this.FillStatusBarPanel.Alignment = System.Windows.Forms.HorizontalAlignment.Right;
            this.FillStatusBarPanel.BorderStyle = System.Windows.Forms.StatusBarPanelBorderStyle.None;
            this.FillStatusBarPanel.Name = "FillStatusBarPanel";
            this.FillStatusBarPanel.Text = "Цвет заливки: ";
            this.FillStatusBarPanel.Width = 88;
            // 
            // FillDrawStatusBarPanel
            // 
            this.FillDrawStatusBarPanel.Name = "FillDrawStatusBarPanel";
            this.FillDrawStatusBarPanel.Style = System.Windows.Forms.StatusBarPanelStyle.OwnerDraw;
            this.FillDrawStatusBarPanel.Text = "Цвет";
            this.FillDrawStatusBarPanel.ToolTipText = "Цвет заливки";
            this.FillDrawStatusBarPanel.Width = 22;
            // 
            // CursorStatusBarPanel
            // 
            this.CursorStatusBarPanel.Name = "CursorStatusBarPanel";
            this.CursorStatusBarPanel.Text = "Курсор: X 0 Y 0";
            this.CursorStatusBarPanel.Width = 132;
            // 
            // CanvasSizeStatusBarPanel
            // 
            this.CanvasSizeStatusBarPanel.Name = "CanvasSizeStatusBarPanel";
            this.CanvasSizeStatusBarPanel.Text = "Холст: W 0 H 0";
            this.CanvasSizeStatusBarPanel.Width = 132;
            // 
            // GridPitchStatusBarPanel
            // 
            this.GridPitchStatusBarPanel.Name = "GridPitchStatusBarPanel";
            this.GridPitchStatusBarPanel.Text = "Шаг сетки: 10";
            this.GridPitchStatusBarPanel.Width = 88;
            // 
            // TextStatusPanel
            // 
            this.TextStatusPanel.BorderStyle = System.Windows.Forms.StatusBarPanelBorderStyle.None;
            this.TextStatusPanel.Name = "TextStatusPanel";
            this.TextStatusPanel.Width = 176;
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton1,
            this.toolStripButton2,
            this.saveToolStripButton,
            this.saveAsToolStripButton,
            this.toolStripSeparator1,
            this.resizeToolStripButton,
            this.toolStripSeparator2,
            this.lineColorToolStripButton,
            this.lineWidthToolStripButton,
            this.backgroundColorToolStripButton,
            this.fontChoiceToolStripButton,
            this.deleteToolStripButton,
            this.toolStripSeparator5,
            this.copyToolStripButton,
            this.copyMetaToolStripButton,
            this.cutToolStripButton,
            this.pasteToolStripButton,
            this.selectAllToolStripButton,
            this.alignToGridToolStripButton,
            this.editToolStripButton,
            this.toolStripSeparator3,
            this.cursorToolStripButton,
            this.rectangleToolStripButton,
            this.ellipseToolStripButton,
            this.lineToolStripButton,
            this.curveToolStripButton,
            this.textToolStripButton,
            this.toolStripSeparator4,
            this.fillCheckToolStripButton,
            this.toolStripSeparator6,
            this.gridToolStripButton,
            this.gridPitchToolStripButton,
            this.snapToGridToolStripButton});
            this.toolStrip1.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.HorizontalStackWithOverflow;
            this.toolStrip1.Location = new System.Drawing.Point(0, 24);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1008, 25);
            this.toolStrip1.TabIndex = 5;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton1.Text = "Новый файл";
            this.toolStripButton1.Click += new System.EventHandler(this.New_Click);
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton2.Image")));
            this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton2.Text = "Открыть";
            this.toolStripButton2.Click += new System.EventHandler(this.Open_Click);
            // 
            // saveToolStripButton
            // 
            this.saveToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.saveToolStripButton.Enabled = false;
            this.saveToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("saveToolStripButton.Image")));
            this.saveToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.saveToolStripButton.Name = "saveToolStripButton";
            this.saveToolStripButton.Size = new System.Drawing.Size(23, 22);
            this.saveToolStripButton.Text = "Сохранить";
            this.saveToolStripButton.Click += new System.EventHandler(this.Save_Click);
            // 
            // saveAsToolStripButton
            // 
            this.saveAsToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.saveAsToolStripButton.Enabled = false;
            this.saveAsToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("saveAsToolStripButton.Image")));
            this.saveAsToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.saveAsToolStripButton.Name = "saveAsToolStripButton";
            this.saveAsToolStripButton.Size = new System.Drawing.Size(23, 22);
            this.saveAsToolStripButton.Text = "Сохранить как...";
            this.saveAsToolStripButton.Click += new System.EventHandler(this.SaveAs_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // resizeToolStripButton
            // 
            this.resizeToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.resizeToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("resizeToolStripButton.Image")));
            this.resizeToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.resizeToolStripButton.Name = "resizeToolStripButton";
            this.resizeToolStripButton.Size = new System.Drawing.Size(23, 22);
            this.resizeToolStripButton.Text = "Выбор размера";
            this.resizeToolStripButton.Click += new System.EventHandler(this.CanvasSize_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // lineColorToolStripButton
            // 
            this.lineColorToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.lineColorToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("lineColorToolStripButton.Image")));
            this.lineColorToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.lineColorToolStripButton.Name = "lineColorToolStripButton";
            this.lineColorToolStripButton.Size = new System.Drawing.Size(23, 22);
            this.lineColorToolStripButton.Text = "Цвет пера";
            this.lineColorToolStripButton.Click += new System.EventHandler(this.LineColor_Click);
            // 
            // lineWidthToolStripButton
            // 
            this.lineWidthToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.lineWidthToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("lineWidthToolStripButton.Image")));
            this.lineWidthToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.lineWidthToolStripButton.Name = "lineWidthToolStripButton";
            this.lineWidthToolStripButton.Size = new System.Drawing.Size(23, 22);
            this.lineWidthToolStripButton.Text = "Размер пера";
            this.lineWidthToolStripButton.Click += new System.EventHandler(this.LineWidth_Click);
            // 
            // backgroundColorToolStripButton
            // 
            this.backgroundColorToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.backgroundColorToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("backgroundColorToolStripButton.Image")));
            this.backgroundColorToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.backgroundColorToolStripButton.Name = "backgroundColorToolStripButton";
            this.backgroundColorToolStripButton.Size = new System.Drawing.Size(23, 22);
            this.backgroundColorToolStripButton.Text = "Цвет заливки";
            this.backgroundColorToolStripButton.Click += new System.EventHandler(this.FillColor_Click);
            // 
            // fontChoiceToolStripButton
            // 
            this.fontChoiceToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.fontChoiceToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("fontChoiceToolStripButton.Image")));
            this.fontChoiceToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.fontChoiceToolStripButton.Name = "fontChoiceToolStripButton";
            this.fontChoiceToolStripButton.Size = new System.Drawing.Size(23, 22);
            this.fontChoiceToolStripButton.Text = "Выбор шрифта";
            this.fontChoiceToolStripButton.Click += new System.EventHandler(this.FontChoice_Click);
            // 
            // deleteToolStripButton
            // 
            this.deleteToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.deleteToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("deleteToolStripButton.Image")));
            this.deleteToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.deleteToolStripButton.Name = "deleteToolStripButton";
            this.deleteToolStripButton.Size = new System.Drawing.Size(23, 22);
            this.deleteToolStripButton.Text = "Удалить";
            this.deleteToolStripButton.Click += new System.EventHandler(this.Delete_Click);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(6, 25);
            // 
            // copyToolStripButton
            // 
            this.copyToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.copyToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("copyToolStripButton.Image")));
            this.copyToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.copyToolStripButton.Name = "copyToolStripButton";
            this.copyToolStripButton.Size = new System.Drawing.Size(23, 22);
            this.copyToolStripButton.Text = "Копировать";
            this.copyToolStripButton.Click += new System.EventHandler(this.Copy_Click);
            // 
            // copyMetaToolStripButton
            // 
            this.copyMetaToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.copyMetaToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("copyMetaToolStripButton.Image")));
            this.copyMetaToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.copyMetaToolStripButton.Name = "copyMetaToolStripButton";
            this.copyMetaToolStripButton.Size = new System.Drawing.Size(23, 22);
            this.copyMetaToolStripButton.Text = "Копировать (метафайл)";
            this.copyMetaToolStripButton.Click += new System.EventHandler(this.CopyMeta_Click);
            // 
            // cutToolStripButton
            // 
            this.cutToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.cutToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("cutToolStripButton.Image")));
            this.cutToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.cutToolStripButton.Name = "cutToolStripButton";
            this.cutToolStripButton.Size = new System.Drawing.Size(23, 22);
            this.cutToolStripButton.Text = "Вырезать";
            this.cutToolStripButton.Click += new System.EventHandler(this.Cut_Click);
            // 
            // pasteToolStripButton
            // 
            this.pasteToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.pasteToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("pasteToolStripButton.Image")));
            this.pasteToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.pasteToolStripButton.Name = "pasteToolStripButton";
            this.pasteToolStripButton.Size = new System.Drawing.Size(23, 22);
            this.pasteToolStripButton.Text = "Вставить";
            this.pasteToolStripButton.Click += new System.EventHandler(this.Paste_Click);
            // 
            // selectAllToolStripButton
            // 
            this.selectAllToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.selectAllToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("selectAllToolStripButton.Image")));
            this.selectAllToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.selectAllToolStripButton.Name = "selectAllToolStripButton";
            this.selectAllToolStripButton.Size = new System.Drawing.Size(23, 22);
            this.selectAllToolStripButton.Text = "Выбрать всё";
            this.selectAllToolStripButton.Click += new System.EventHandler(this.SelectAll_Click);
            // 
            // alignToGridToolStripButton
            // 
            this.alignToGridToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.alignToGridToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("alignToGridToolStripButton.Image")));
            this.alignToGridToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.alignToGridToolStripButton.Name = "alignToGridToolStripButton";
            this.alignToGridToolStripButton.Size = new System.Drawing.Size(23, 22);
            this.alignToGridToolStripButton.Text = "Выровнять по сетке";
            this.alignToGridToolStripButton.Click += new System.EventHandler(this.AlignToGrid_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 25);
            // 
            // cursorToolStripButton
            // 
            this.cursorToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.cursorToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("cursorToolStripButton.Image")));
            this.cursorToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.cursorToolStripButton.Name = "cursorToolStripButton";
            this.cursorToolStripButton.Size = new System.Drawing.Size(23, 22);
            this.cursorToolStripButton.Text = "Курсор";
            this.cursorToolStripButton.Click += new System.EventHandler(this.Cursor_Click);
            // 
            // rectangleToolStripButton
            // 
            this.rectangleToolStripButton.Checked = true;
            this.rectangleToolStripButton.CheckState = System.Windows.Forms.CheckState.Checked;
            this.rectangleToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.rectangleToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("rectangleToolStripButton.Image")));
            this.rectangleToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.rectangleToolStripButton.Name = "rectangleToolStripButton";
            this.rectangleToolStripButton.Size = new System.Drawing.Size(23, 22);
            this.rectangleToolStripButton.Text = "Прямоугольник";
            this.rectangleToolStripButton.Click += new System.EventHandler(this.Rectangle_Click);
            // 
            // ellipseToolStripButton
            // 
            this.ellipseToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.ellipseToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("ellipseToolStripButton.Image")));
            this.ellipseToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ellipseToolStripButton.Name = "ellipseToolStripButton";
            this.ellipseToolStripButton.Size = new System.Drawing.Size(23, 22);
            this.ellipseToolStripButton.Text = "Эллипс";
            this.ellipseToolStripButton.Click += new System.EventHandler(this.Ellipse_Click);
            // 
            // lineToolStripButton
            // 
            this.lineToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.lineToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("lineToolStripButton.Image")));
            this.lineToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.lineToolStripButton.Name = "lineToolStripButton";
            this.lineToolStripButton.Size = new System.Drawing.Size(23, 22);
            this.lineToolStripButton.Text = "Прямая линия";
            this.lineToolStripButton.Click += new System.EventHandler(this.Line_Click);
            // 
            // curveToolStripButton
            // 
            this.curveToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.curveToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("curveToolStripButton.Image")));
            this.curveToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.curveToolStripButton.Name = "curveToolStripButton";
            this.curveToolStripButton.Size = new System.Drawing.Size(23, 22);
            this.curveToolStripButton.Text = "Кривая линия";
            this.curveToolStripButton.Click += new System.EventHandler(this.Curve_Click);
            // 
            // textToolStripButton
            // 
            this.textToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.textToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("textToolStripButton.Image")));
            this.textToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.textToolStripButton.Name = "textToolStripButton";
            this.textToolStripButton.Size = new System.Drawing.Size(23, 22);
            this.textToolStripButton.Text = "Текст";
            this.textToolStripButton.Click += new System.EventHandler(this.Text_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 25);
            // 
            // fillCheckToolStripButton
            // 
            this.fillCheckToolStripButton.Checked = true;
            this.fillCheckToolStripButton.CheckState = System.Windows.Forms.CheckState.Checked;
            this.fillCheckToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.fillCheckToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("fillCheckToolStripButton.Image")));
            this.fillCheckToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.fillCheckToolStripButton.Name = "fillCheckToolStripButton";
            this.fillCheckToolStripButton.Size = new System.Drawing.Size(23, 22);
            this.fillCheckToolStripButton.Text = "Заливка";
            this.fillCheckToolStripButton.Click += new System.EventHandler(this.FillCheck_Click);
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(6, 25);
            // 
            // gridToolStripButton
            // 
            this.gridToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.gridToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("gridToolStripButton.Image")));
            this.gridToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.gridToolStripButton.Name = "gridToolStripButton";
            this.gridToolStripButton.Size = new System.Drawing.Size(23, 22);
            this.gridToolStripButton.Text = "Сетка";
            this.gridToolStripButton.Click += new System.EventHandler(this.Grid_Click);
            // 
            // gridPitchToolStripButton
            // 
            this.gridPitchToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.gridPitchToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("gridPitchToolStripButton.Image")));
            this.gridPitchToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.gridPitchToolStripButton.Name = "gridPitchToolStripButton";
            this.gridPitchToolStripButton.Size = new System.Drawing.Size(23, 22);
            this.gridPitchToolStripButton.Text = "Шаг сетки";
            this.gridPitchToolStripButton.Click += new System.EventHandler(this.GridPitch_Click);
            // 
            // snapToGridToolStripButton
            // 
            this.snapToGridToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.snapToGridToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("snapToGridToolStripButton.Image")));
            this.snapToGridToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.snapToGridToolStripButton.Name = "snapToGridToolStripButton";
            this.snapToGridToolStripButton.Size = new System.Drawing.Size(23, 22);
            this.snapToGridToolStripButton.Text = "Привязка к сетке";
            this.snapToGridToolStripButton.Click += new System.EventHandler(this.SnapToGrid_Click);
            // 
            // editToolStripButton
            // 
            this.editToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.editToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("editToolStripButton.Image")));
            this.editToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.editToolStripButton.Name = "editToolStripButton";
            this.editToolStripButton.Size = new System.Drawing.Size(23, 22);
            this.editToolStripButton.Text = "Редактировать";
            this.editToolStripButton.Click += new System.EventHandler(this.Edit_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1008, 729);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.StatusBar);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Никифоров Глеб | Графический редактор";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.WidthStatusBarPanel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ColorStatusBarPanel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ColorDrawStatusBarPanel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.FillStatusBarPanel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.FillDrawStatusBarPanel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.CursorStatusBarPanel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.CanvasSizeStatusBarPanel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GridPitchStatusBarPanel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TextStatusPanel)).EndInit();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem projectToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem newToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem окноToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem openToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveAsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem parametersToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lineColorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem backgroundColorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lineWidthToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem resizeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem figureToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lineToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ellipseToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rectangleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem curveToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fillToolStripMenuItem;
        private System.Windows.Forms.StatusBar StatusBar;
        private System.Windows.Forms.StatusBarPanel WidthStatusBarPanel;
        private System.Windows.Forms.StatusBarPanel ColorStatusBarPanel;
        private System.Windows.Forms.StatusBarPanel ColorDrawStatusBarPanel;
        private System.Windows.Forms.StatusBarPanel FillStatusBarPanel;
        private System.Windows.Forms.StatusBarPanel FillDrawStatusBarPanel;
        private System.Windows.Forms.StatusBarPanel CursorStatusBarPanel;
        private System.Windows.Forms.StatusBarPanel CanvasSizeStatusBarPanel;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private System.Windows.Forms.ToolStripButton saveToolStripButton;
        private System.Windows.Forms.ToolStripButton saveAsToolStripButton;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton resizeToolStripButton;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton lineColorToolStripButton;
        private System.Windows.Forms.ToolStripButton backgroundColorToolStripButton;
        private System.Windows.Forms.ToolStripButton lineWidthToolStripButton;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripButton rectangleToolStripButton;
        private System.Windows.Forms.ToolStripButton ellipseToolStripButton;
        private System.Windows.Forms.ToolStripButton lineToolStripButton;
        private System.Windows.Forms.ToolStripButton curveToolStripButton;
        private System.Windows.Forms.ToolStripButton fillCheckToolStripButton;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripButton textToolStripButton;
        private System.Windows.Forms.ToolStripButton fontChoiceToolStripButton;
        private System.Windows.Forms.ToolStripMenuItem fontChoiceToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem textToolStripMenuItem;
        private System.Windows.Forms.StatusBarPanel TextStatusPanel;
        private System.Windows.Forms.ToolStripButton cursorToolStripButton;
        private System.Windows.Forms.ToolStripMenuItem cursorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deleteToolStripMenuItem;
        private System.Windows.Forms.ToolStripButton deleteToolStripButton;
        private System.Windows.Forms.ToolStripMenuItem правкаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem copyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem copyMetaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pasteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem selectAllToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripButton copyToolStripButton;
        private System.Windows.Forms.ToolStripButton copyMetaToolStripButton;
        private System.Windows.Forms.ToolStripButton cutToolStripButton;
        private System.Windows.Forms.ToolStripButton pasteToolStripButton;
        private System.Windows.Forms.ToolStripButton selectAllToolStripButton;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.ToolStripMenuItem alignToGridToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem attributesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gridToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gridPitchToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem snapToGridToolStripMenuItem;
        private System.Windows.Forms.ToolStripButton gridToolStripButton;
        private System.Windows.Forms.ToolStripButton gridPitchToolStripButton;
        private System.Windows.Forms.ToolStripButton alignToGridToolStripButton;
        private System.Windows.Forms.ToolStripButton snapToGridToolStripButton;
        private System.Windows.Forms.StatusBarPanel GridPitchStatusBarPanel;
        private System.Windows.Forms.ToolStripMenuItem editToolStripMenuItem;
        private System.Windows.Forms.ToolStripButton editToolStripButton;
    }
}

