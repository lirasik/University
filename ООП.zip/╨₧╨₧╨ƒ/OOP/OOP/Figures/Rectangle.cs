﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OOP.Figures
{
    [Serializable()]
    public class Rectangle : Figure
    {

        public Rectangle(Point p)
            : base(p)
        {
            type = FigureType.Rectangle;
            fillable = true;
        }
        public Rectangle(Point p1, Point p2)
            : base(p1)
        {
            type = FigureType.Rectangle;
            fillable = true;
            Update(p1, p2);
        }

        public Rectangle(Point p, bool isCursor)
            : base(p)
        {
            if (isCursor)
            {
                type = FigureType.Cursor;
            }
            else
            {
                type = FigureType.Rectangle;
                fillable = true;
            }
        }

        public override void Draw(Graphics g, Point margin)
        {
            System.Drawing.Rectangle rect = GetMarginArea(margin);
            if (Filled) g.FillRectangle(BackBrush, rect);
            g.DrawRectangle(SolidPen, rect);
        }

        public override void Update(Point point1, Point point2)
        {
            UpdatePoints(point1, point2);
        }

        public override void DrawDash(Graphics g, Point margin)
        {
            System.Drawing.Rectangle rect = GetMarginArea(margin);
            g.DrawRectangle(DashPen, rect);
        }
        public void DrawBackground(Graphics g, Point margin)
        {
            System.Drawing.Rectangle rect = GetMarginArea(margin);
            if (Filled) g.FillRectangle(BackBrush, rect);
        }

        public override List<Control> GetControls()
        {
            var controls = new List<Control>
            {
                GetCoordinatesControl(),
                GetLineWidthControl(),
                GetLineColorControl(),
                GetBackgroundColorControl(),
                GetFillControl()
            };
            return controls;
        }

        public override void SetParameters(Control.ControlCollection controls)
        {
            var pointsControls = ((FlowLayoutPanel)controls[0]).Controls;
            SetPoints(pointsControls);
            var lineWidthControls = ((FlowLayoutPanel)controls[1]).Controls;
            SetLineWidth(lineWidthControls);
            var lineColorControls = ((FlowLayoutPanel)controls[2]).Controls;
            SetLineColor(lineColorControls);
            var backgroundColorControls = ((FlowLayoutPanel)controls[3]).Controls;
            SetBackgroundColor(backgroundColorControls);
            SetFill((CheckBox)controls[4]);
        }
    }
}
