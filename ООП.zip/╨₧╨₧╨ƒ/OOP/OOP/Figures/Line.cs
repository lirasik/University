﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OOP.Figures
{
    [Serializable()]
    public class Line : Figure
    {
        private Point drawFirstPoint = Point.Empty;
        private Point drawLastPoint = Point.Empty;

        public Line(Point p)
            : base(p)
        {
            type = FigureType.Line;
            drawFirstPoint = drawLastPoint = p;
        }

        public override void Draw(Graphics g, Point margin)
        {
            var p1 = SumPoints(drawFirstPoint, margin);
            var p2 = SumPoints(drawLastPoint, margin);
            g.DrawLine(SolidPen, p1, p2);
        }

        public override void Update(Point point1, Point point2)
        {
            drawFirstPoint = point1;
            drawLastPoint = point2;
            UpdatePoints(point1, point2);
        }

        public override void Move(Point shift)
        {
            drawFirstPoint = SumPoints(drawFirstPoint, shift);
            drawLastPoint = SumPoints(drawLastPoint, shift);
            base.Move(shift);
        }

        public override void Align(int gridPitch)
        {
            base.Align(gridPitch);
            ProcessPointChanges();
        }
        public override void Resize(MarkerID destination, Point amount)
        {
            base.Resize(destination, amount);
            ProcessPointChanges();
        }

        private void ProcessPointChanges()
        {
            drawFirstPoint = new Point(
                drawFirstPoint.X < drawLastPoint.X ? FirstPoint.X : SecondPoint.X,
                drawFirstPoint.Y < drawLastPoint.Y ? FirstPoint.Y : SecondPoint.Y);
            drawLastPoint = new Point(
                drawLastPoint.X < drawFirstPoint.X ? FirstPoint.X : SecondPoint.X,
                drawLastPoint.Y < drawFirstPoint.Y ? FirstPoint.Y : SecondPoint.Y);
        }

        public override void DrawDash(Graphics g, Point margin)
        {
            var p1 = SumPoints(drawFirstPoint, margin);
            var p2 = SumPoints(drawLastPoint, margin);
            g.DrawLine(DashPen, p1, p2);
        }

        public override List<Control> GetControls()
        {
            var controls = new List<Control>
            {
                GetCoordinatesControl(),
                GetLineWidthControl(),
                GetLineColorControl()
            };
            return controls;
        }

        protected override Control GetCoordinatesControl()
        {
            var flowLayoutPanel = (FlowLayoutPanel)base.GetCoordinatesControl();
            flowLayoutPanel.Controls[1].Text
                = string.Format("{0},{1}", drawFirstPoint.X, drawFirstPoint.Y);
            flowLayoutPanel.Controls[3].Text
                = string.Format("{0},{1}", drawLastPoint.X, drawLastPoint.Y);
            return flowLayoutPanel;
        }

        public override void SetParameters(Control.ControlCollection controls)
        {
            var pointsControls = ((FlowLayoutPanel)controls[0]).Controls;
            SetPoints(pointsControls);
            var lineWidthControls = ((FlowLayoutPanel)controls[1]).Controls;
            SetLineWidth(lineWidthControls);
            var lineColorControls = ((FlowLayoutPanel)controls[2]).Controls;
            SetLineColor(lineColorControls);
        }

        protected override void SetPoints(Control.ControlCollection controls)
        {
            var pointsText1 = controls[1].Text.Split(',');
            if (pointsText1.Length >= 2)
            {
                int firstPointX = drawFirstPoint.X;
                int firstPointY = drawFirstPoint.Y;
                if (int.TryParse(pointsText1[0], out int x1))
                {
                    firstPointX = x1;
                }
                if (int.TryParse(pointsText1[1], out int y1))
                {
                    firstPointY = y1;
                }
                drawFirstPoint = new Point(firstPointX, firstPointY);
            }

            var pointsText2 = controls[3].Text.Split(',');
            if (pointsText2.Length >= 2)
            {
                int secondPointX = drawLastPoint.X;
                int secondPointY = drawLastPoint.Y;
                if (int.TryParse(pointsText2[0], out int x2))
                {
                    secondPointX = x2;
                }
                if (int.TryParse(pointsText2[1], out int y2))
                {
                    secondPointY = y2;
                }
                drawLastPoint = new Point(secondPointX, secondPointY);
            }
            UpdatePoints(drawFirstPoint, drawLastPoint);
        }
    }
}
