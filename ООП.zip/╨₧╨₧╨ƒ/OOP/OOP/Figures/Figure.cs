﻿using OOP.Forms;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OOP.Figures
{
    [Serializable()]
    public abstract class Figure
    {
        protected FigureType type;
        protected bool fillable = false;

        private Point firstPoint = Point.Empty;
        private Point secondPoint = Point.Empty;

        public FigureType Type { get => type; }
        public bool Fillable { get => fillable; }
        public Color LineColor { get; set; } = Color.Black;
        public Color BackgroundColor { get; set; } = Color.White;
        public int LineWidth { get; set; } = 1;
        public Point FirstPoint
        {
            get
            {
                return firstPoint;
            }
            protected set
            {
                firstPoint = value;
            }
        }
        public Point SecondPoint
        {
            get
            {
                return secondPoint;
            }
            protected set
            {
                secondPoint = value;
            }
        }
        public bool Filled { get; set; } = false;

        public Size Size
        {
            get
            {
                return new Size(SecondPoint.X - FirstPoint.X, SecondPoint.Y - FirstPoint.Y);
            }
        }
        [NonSerialized()] public bool Selected = false;

        protected System.Drawing.Rectangle Area => new System.Drawing.Rectangle(FirstPoint, Size);

        public Figure(Point p)
        {
            firstPoint = secondPoint = p;
        }

        public abstract void Draw(Graphics g, Point margin);
        public abstract void Update(Point point1, Point point2);
        public virtual void Move(Point shift)
        {
            FirstPoint = SumPoints(FirstPoint, shift);
            SecondPoint = SumPoints(SecondPoint, shift);
        }

        protected bool IsUpdatedPoints(Tuple<Point, Point> points)
        {
            return IsUpdatedPoints(points.Item1, points.Item2);
        }
        protected bool IsUpdatedPoints(Point point1, Point point2)
        {
            return point1.X < point2.X && point1.Y < point2.Y;
        }

        protected Tuple<Point, Point> GetUpdatedPoints(Point point1, Point point2)
        {
            Point new1 = new Point(
                Math.Min(point1.X, point2.X),
                Math.Min(point1.Y, point2.Y));
            Point new2 = new Point(
                Math.Max(point1.X, point2.X),
                Math.Max(point1.Y, point2.Y));
            return new Tuple<Point, Point>(new1, new2);
        }
        protected void UpdatePoints(Point point1, Point point2)
        {
            var updatedPoints = GetUpdatedPoints(point1, point2);
            FirstPoint = updatedPoints.Item1;
            SecondPoint = updatedPoints.Item2;
        }
        protected void UpdatePoints()
        {
            UpdatePoints(FirstPoint, SecondPoint);
        }
        public abstract void DrawDash(Graphics g, Point margin);

        public void DrawArea(Graphics g, Point margin)
        {
            var rect = GetMarginArea(margin);
            Pen pen = new Pen(Color.Black, 1)
            {
                DashStyle = System.Drawing.Drawing2D.DashStyle.Dot
            };
            g.DrawRectangle(pen, rect);
        }

        public void DrawMoved(Graphics g, Point margin, Point shift)
        {
            margin.X += shift.X;
            margin.Y += shift.Y;
            DrawDash(g, margin);
            DrawArea(g, margin);
        }

        public void DrawMarkers(Graphics g, Point margin)
        {
            DrawMarkers(g, margin, Point.Empty);
        }
        public void DrawMarkers(Graphics g, Point margin, Point shift)
        {
            foreach (MarkerID markerId in Enum.GetValues(typeof(MarkerID)))
            {
                if (markerId == MarkerID.None)
                {
                    break;
                }
                DrawMarker(g, GetBorderPosition(markerId, margin, shift));
            }
        }

        private void DrawMarker(Graphics g, Point position)
        {
            var marker = GetMarkerArea(position);
            g.FillRectangle(MarkerBrush, marker);
            g.DrawRectangle(MarkerPen, marker);
        }

        private System.Drawing.Rectangle GetMarkerArea(MarkerID markerID)
        {
            return GetMarkerArea(GetBorderPosition(markerID));
        }
        private System.Drawing.Rectangle GetMarkerArea(Point position)
        {
            return new System.Drawing.Rectangle(
                position.X - MarkerSize.Width / 2,
                position.Y - MarkerSize.Height / 2,
                MarkerSize.Width,
                MarkerSize.Height);
        }

        private Point GetBorderPosition(MarkerID markerID, Point margin, Point shift)
        {
            return SumPoints(GetBorderPosition(markerID, margin), shift);
        }
        private Point GetBorderPosition(MarkerID markerID, Point margin)
        {
            return SumPoints(GetBorderPosition(markerID), margin);
        }
        private Point GetBorderPosition(MarkerID markerID)
        {
            switch (markerID)
            {
                case MarkerID.TopLeft:
                    return FirstPoint;
                case MarkerID.TopMiddle:
                    return new Point(FirstPoint.X + Size.Width / 2, FirstPoint.Y);
                case MarkerID.TopRight:
                    return new Point(SecondPoint.X, FirstPoint.Y);
                case MarkerID.MiddleLeft:
                    return new Point(FirstPoint.X, FirstPoint.Y + Size.Height / 2);
                case MarkerID.MiddleRight:
                    return new Point(SecondPoint.X, FirstPoint.Y + Size.Height / 2);
                case MarkerID.BottomLeft:
                    return new Point(FirstPoint.X, SecondPoint.Y);
                case MarkerID.BottomMiddle:
                    return new Point(FirstPoint.X + Size.Width / 2, SecondPoint.Y);
                case MarkerID.BottomRight:
                    return SecondPoint;
                case MarkerID.None:
                default:
                    throw new Exception("Undefined marker identifier");
            }
        }
        public void HiglightMarker(Graphics g, MarkerID markerID, Point margin, Point shift)
        {
            var marker = GetMarkerArea(GetBorderPosition(markerID, margin, shift));
            g.FillRectangle(new SolidBrush(Color.Yellow), marker);
            g.DrawRectangle(MarkerPen, marker);
        }
        public MarkerID GetMarkerID(Point p, Point margin)
        {
            return GetMarkerID(new Point(p.X - margin.X, p.Y - margin.Y));
        }
        private MarkerID GetMarkerID(Point p)
        {
            foreach (MarkerID markerID in Enum.GetValues(typeof(MarkerID)))
            {
                if (markerID == MarkerID.None)
                {
                    break;
                }
                if (GetMarkerArea(markerID).IntersectsWith(new System.Drawing.Rectangle(p, new Size(1, 1))))
                {
                    return markerID;
                }
            }
            return MarkerID.None;
        }

        public void DrawSelected(Graphics g, Point margin)
        {
            DrawMoved(g, margin, Point.Empty);
        }

        public virtual void Align(int gridPitch)
        {
            firstPoint = new Point(RoundTo(firstPoint.X, gridPitch), RoundTo(firstPoint.Y, gridPitch));
            secondPoint = new Point(RoundTo(secondPoint.X, gridPitch), RoundTo(secondPoint.Y, gridPitch));
        }

        public virtual Tuple<Point, Point> GetResizedPoints(MarkerID destination, Point amount)
        {
            Point first = FirstPoint;
            Point second = SecondPoint;
            switch (destination)
            {
                case MarkerID.TopLeft:
                    first = new Point(
                        first.X + amount.X,
                        first.Y + amount.Y);
                    break;
                case MarkerID.TopMiddle:
                    first = new Point(
                        first.X,
                        first.Y + amount.Y);
                    break;
                case MarkerID.TopRight:
                    first = new Point(
                        first.X,
                        first.Y + amount.Y);
                    second = new Point(
                        second.X + amount.X,
                        second.Y);
                    break;
                case MarkerID.MiddleLeft:
                    first = new Point(
                        first.X + amount.X,
                        first.Y);
                    break;
                case MarkerID.MiddleRight:
                    second = new Point(
                        second.X + amount.X,
                        second.Y);
                    break;
                case MarkerID.BottomLeft:
                    first = new Point(
                        first.X + amount.X,
                        first.Y);
                    second = new Point(
                        second.X,
                        second.Y + amount.Y);
                    break;
                case MarkerID.BottomMiddle:
                    second = new Point(
                        second.X,
                        second.Y + amount.Y);
                    break;
                case MarkerID.BottomRight:
                    second = new Point(
                        second.X + amount.X,
                        second.Y + amount.Y);
                    break;
            }
            return new Tuple<Point, Point>(first, second);
        }

        public virtual void Resize(MarkerID destination, Point amount)
        {
            var newPoints = GetResizedPoints(destination, amount);
            if (IsUpdatedPoints(newPoints))
            {
                UpdatePoints(newPoints.Item1, newPoints.Item2);
            }
        }

        public virtual void DrawResized(Graphics g, Point margin, MarkerID destination, Point amount)
        {
            bool toResize = IsUpdatedPoints(GetResizedPoints(destination, amount));
            if (toResize)
            {
                Resize(destination, amount);
            }
            DrawSelected(g, margin);
            DrawMarkers(g, margin);
            if (toResize)
            {
                Resize(destination, new Point(-amount.X, -amount.Y));
            }
        }

        static private int RoundTo(int value, int border)
        {
            return (value + border / 2) / border * border;
        }
        static protected Point SumPoints(Point first, Point second)
        {
            return new Point(
                first.X + second.X,
                first.Y + second.Y);
        }
        static protected Point SumPoints(Point first, Point second, Point third)
        {
            return new Point(
                first.X + second.X + third.X,
                first.Y + second.Y + third.Y);
        }

        public System.Drawing.Rectangle GetMarginArea(Point margin)
        {
            System.Drawing.Rectangle area = Area;
            area.X += margin.X;
            area.Y += margin.Y;
            return area;
        }

        abstract public List<Control> GetControls();
        abstract public void SetParameters(Control.ControlCollection controls);
        protected virtual Control GetCoordinatesControl()
        {
            var panel = new FlowLayoutPanel()
            {
                Size = new Size(280, 50)
            };
            var label1 = new Label()
            {
                Text = "Координаты первой точки:",
                Size = new Size(150, 25),
                TextAlign = ContentAlignment.MiddleLeft
            };
            var textBox1 = new TextBox()
            {
                Text = string.Format("{0},{1}", FirstPoint.X, FirstPoint.Y),
                Size = new Size(80, 25)
            };
            var label2 = new Label()
            {
                Text = "Координаты второй точки:",
                Size = new Size(150, 25),
                TextAlign = ContentAlignment.MiddleLeft
            };
            var textBox2 = new TextBox()
            {
                Text = string.Format("{0},{1}", SecondPoint.X, SecondPoint.Y),
                Size = new Size(80, 25)
            };
            panel.Controls.AddRange(new Control[] { label1, textBox1, label2, textBox2 });
            return panel;
        }
        protected virtual Control GetLineWidthControl()
        {
            var panel = new FlowLayoutPanel()
            {
                Size = new Size(140, 25)
            };
            var label = new Label()
            {
                Text = "Размер пера:",
                Size = new Size(80, 25),
                TextAlign = ContentAlignment.MiddleLeft
            };
            var textBox = new TextBox()
            {
                Text = LineWidth.ToString(),
                Size = new Size(40, 25),
                Tag = LineWidth,
                ReadOnly = true,
                BackColor = System.Drawing.SystemColors.Window
        };
            textBox.MouseClick += (object sender, MouseEventArgs e) =>
            {
                var widthDialog = new WidthDialog((int)textBox.Tag);
                if (widthDialog.ShowDialog() == DialogResult.OK)
                {
                    textBox.Text = widthDialog.width.ToString();
                    textBox.Tag = widthDialog.width;
                }
            };
            panel.Controls.AddRange(new Control[] { label, textBox });
            return panel;
        }
        protected virtual Control GetFillControl()
        {
            return new CheckBox()
            {
                Text = "Заливка",
                Size = new Size(80, 25),
                TextAlign = ContentAlignment.MiddleLeft,
                Checked = Filled
            };
        }
        protected virtual Control GetLineColorControl()
        {
            var panel = new FlowLayoutPanel()
            {
                Size = new Size(200, 25)
            };
            var label = new Label()
            {
                Text = "Цвет пера:",
                Size = new Size(80, 25),
                TextAlign = ContentAlignment.MiddleLeft
            };
            var textBox = new TextBox()
            {
                BackColor = LineColor,
                Size = new Size(40, 25),
                Tag = LineColor,
                ReadOnly = true
            };
            textBox.MouseClick += (object sender, MouseEventArgs e) =>
            {
                var colorDialog = new ColorDialog()
                {
                    Color = (Color)textBox.Tag
                };
                if (colorDialog.ShowDialog() == DialogResult.OK)
                {
                    textBox.BackColor = colorDialog.Color;
                    textBox.Tag = colorDialog.Color;
                    textBox.BackColor = colorDialog.Color;
                }
            };
            panel.Controls.AddRange(new Control[] { label, textBox });
            return panel;
        }
        protected virtual Control GetBackgroundColorControl()
        {
            var panel = new FlowLayoutPanel()
            {
                Size = new Size(200, 25)
            };
            var label = new Label()
            {
                Text = "Цвет заливки:",
                Size = new Size(80, 25),
                TextAlign = ContentAlignment.MiddleLeft
            };
            var textBox = new TextBox()
            {
                BackColor = BackgroundColor,
                Size = new Size(40, 25),
                Tag = BackgroundColor,
                ReadOnly = true
            };
            textBox.MouseClick += (object sender, MouseEventArgs e) =>
            {
                var colorDialog = new ColorDialog()
                {
                    Color = (Color)textBox.Tag
                };
                if (colorDialog.ShowDialog() == DialogResult.OK)
                {
                    textBox.BackColor = colorDialog.Color;
                    textBox.Tag = colorDialog.Color;
                }
            };
            panel.Controls.AddRange(new Control[] { label, textBox });
            return panel;
        }
        protected virtual void SetPoints(Control.ControlCollection controls)
        {
            var pointsText1 = controls[1].Text.Split(',');
            if (pointsText1.Length >= 2)
            {
                int firstPointX = FirstPoint.X;
                int firstPointY = FirstPoint.Y;
                if (int.TryParse(pointsText1[0], out int x1))
                {
                    firstPointX = x1;
                }
                if (int.TryParse(pointsText1[1], out int y1))
                {
                    firstPointY = y1;
                }
                FirstPoint = new Point(firstPointX, firstPointY);
            }

            var pointsText2 = controls[3].Text.Split(',');
            if (pointsText2.Length >= 2)
            {
                int secondPointX = SecondPoint.X;
                int secondPointY = SecondPoint.Y;
                if (int.TryParse(pointsText2[0], out int x2))
                {
                    secondPointX = x2;
                }
                if (int.TryParse(pointsText2[1], out int y2))
                {
                    secondPointY = y2;
                }
                SecondPoint = new Point(secondPointX, secondPointY);
            }

            UpdatePoints();
        }
        protected virtual void SetLineWidth(Control.ControlCollection controls)
        {
            var lineWidthText = controls[1].Text;
            if (int.TryParse(lineWidthText, out int lineWidth))
            {
                LineWidth = lineWidth;
            }
        }
        protected virtual void SetLineColor(Control.ControlCollection controls)
        {
            var lineColor = (Color)controls[1].Tag;
            LineColor = lineColor;
        }
        protected virtual void SetBackgroundColor(Control.ControlCollection controls)
        {
            var backgroundColor = (Color)controls[1].Tag;
            BackgroundColor = backgroundColor;
        }
        protected virtual void SetFill(CheckBox control)
        {
            Filled = control.Checked;
        }

        protected Pen SolidPen => new Pen(LineColor, LineWidth)
        {
            DashStyle = System.Drawing.Drawing2D.DashStyle.Solid
        };
        protected Pen DashPen => new Pen(LineColor, LineWidth)
        {
            DashStyle = System.Drawing.Drawing2D.DashStyle.Dash
        };
        protected SolidBrush LineBrush => new SolidBrush(LineColor);
        protected SolidBrush BackBrush => new SolidBrush(BackgroundColor);
        static private Pen MarkerPen => new Pen(Color.Black, 1)
        {
            DashStyle = System.Drawing.Drawing2D.DashStyle.Solid
        };
        static private SolidBrush MarkerBrush => new SolidBrush(Color.White);
        static private Size MarkerSize => new Size(8, 8);
    }
}
