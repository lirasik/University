﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OOP.Figures
{
    [Serializable()]
    public class Text : Figure
    {
        public Font Font;

        public string Inner { get; set; }
            
        public Text(Point p)
            : base(p)
        {
            type = FigureType.Text;
        }

        public override void Draw(Graphics g, Point margin)
        {
            System.Drawing.Rectangle rect = GetMarginArea(margin);
            g.DrawString(Inner, Font, LineBrush, rect);
        }

        public override void Update(Point point1, Point point2)
        {
            UpdatePoints(point1, point2);
        }

        public override void DrawDash(Graphics g, Point margin)
        {
            System.Drawing.Rectangle rect = GetMarginArea(margin);
            g.DrawString(Inner, Font, LineBrush, rect);
            g.DrawRectangle(DashPen, rect);
        }

        public override List<Control> GetControls()
        {
            var controls = new List<Control>
            {
                GetCoordinatesControl(),
                GetTextColorControl(),
                GetFontControl(),
                GetInnerTextControl()
            };
            return controls;
        }

        protected Control GetTextColorControl()
        {
            var panel = (FlowLayoutPanel)GetLineColorControl();
            var label = (Label)panel.Controls[0];
            label.Text = "Цвет текста:";
            return panel;
        }

        protected Control GetFontControl()
        {
            var panel = new FlowLayoutPanel()
            {
                Size = new Size(290, 50)
            };
            var label = new Label()
            { 
                Text = "Шрифт:",
                Size = new Size(50, 50),
                TextAlign = ContentAlignment.MiddleLeft
            };
            var textBox = new TextBox()
            {
                Text = string.Format("{0} {1}pt {2}", Font.Name, Font.Size, Font.Style),
                Font = Font,
                Tag = Font,
                Size = new Size(220, 50),
                ReadOnly = true
            };
            textBox.MouseClick += (object sender, MouseEventArgs e) =>
            {
                var fontDialog = new FontDialog()
                {
                    Font = (Font)textBox.Tag
                };
                if (fontDialog.ShowDialog() == DialogResult.OK)
                {
                    textBox.Text = string.Format("{0} {1}pt {2}", fontDialog.Font.Name, fontDialog.Font.Size, fontDialog.Font.Style);
                    textBox.Font = fontDialog.Font;
                    textBox.Tag = fontDialog.Font;
                }
            };
            panel.Controls.AddRange(new Control[] { label, textBox });
            return panel;
        }

        protected Control GetInnerTextControl()
        {
            var panel = new FlowLayoutPanel()
            {
                Size = new Size(290, 100)
            };
            var label = new Label()
            {
                Text = "Текст:",
                Size = new Size(50, 25),
                TextAlign = ContentAlignment.MiddleLeft
            };
            var textBox = new TextBox()
            {
                Text = Inner,
                Size = new Size(220, 100),
                Multiline = true
            };

            panel.Controls.AddRange(new Control[] { label, textBox });
            return panel;
        }

        public override void SetParameters(Control.ControlCollection controls)
        {
            var pointsControls = ((FlowLayoutPanel)controls[0]).Controls;
            SetPoints(pointsControls);
            var lineColorControls = ((FlowLayoutPanel)controls[1]).Controls;
            SetLineColor(lineColorControls);
            var fontControls = ((FlowLayoutPanel)controls[2]).Controls;
            SetFont(fontControls);
            var textControls = ((FlowLayoutPanel)controls[3]).Controls;
            SetText(textControls);
        }

        protected void SetFont(Control.ControlCollection controls)
        {
            var font = (Font)controls[1].Tag;
            Font = font;
        }

        protected void SetText(Control.ControlCollection controls)
        {
            Inner = controls[1].Text;
        }
    }
}
