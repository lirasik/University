﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OOP.Figures
{
    [Serializable()]
    public class Curve : Figure
    {
        List<Point> points;
        public Curve(Point p)
            : base(p)
        {
            type = FigureType.Curve;
        }

        public override void Draw(Graphics g, Point margin)
        {
            Point[] pArr = points.ToArray();
            for (int i = 0; i < pArr.Length; i++)
            {
                pArr[i].X += margin.X;
                pArr[i].Y += margin.Y;
            }
            g.DrawCurve(SolidPen,pArr);
        }

        public override void Update(Point point1, Point point2)
        {
            if (points == null)
            {
                points = new List<Point>
                {
                    point1
                };
            }
            points.Add(point2);
            FirstPoint = new Point(
                Math.Min(FirstPoint.X, point2.X),
                Math.Min(FirstPoint.Y, point2.Y));
            SecondPoint = new Point(
                Math.Max(SecondPoint.X, point2.X),
                Math.Max(SecondPoint.Y, point2.Y));
            UpdatePoints(FirstPoint, SecondPoint);
        }
        public override void Move(Point shift)
        {
            for (int i = 0; i < points.Count; ++i)
            {
                points[i] = new Point(
                    points[i].X + shift.X,
                    points[i].Y + shift.Y);
            }
            base.Move(shift);
        }

        public override void Align(int gridPitch)
        {
            Point oldFirstPoint = FirstPoint;
            Point oldSecondPoint = SecondPoint;
            base.Align(gridPitch);
            ProcessPointChanges(oldFirstPoint, oldSecondPoint);
        }

        public override void Resize(MarkerID destination, Point amount)
        {
            Point oldFirstPoint = FirstPoint;
            Point oldSecondPoint = SecondPoint;
            base.Resize(destination, amount);
            ProcessPointChanges(oldFirstPoint, oldSecondPoint);
        }

        public override void DrawResized(Graphics g, Point margin, MarkerID destination, Point amount)
        {
            List<Point> savedList = new List<Point>();
            savedList.AddRange(points);
            base.DrawResized(g, margin, destination, amount);
            points = savedList;
        }

        private void ProcessPointChanges(Point oldFirstPoint, Point oldSecondPoint)
        {
            Point oldDifference = new Point(
                oldSecondPoint.X - oldFirstPoint.X,
                oldSecondPoint.Y - oldFirstPoint.Y);
            Point difference = new Point(
                SecondPoint.X - FirstPoint.X,
                SecondPoint.Y - FirstPoint.Y);
            PointF scale = new PointF(
                oldDifference.X != 0 ? (float)difference.X / oldDifference.X : 1,
                oldDifference.Y != 0 ? (float)difference.Y / oldDifference.Y : 1);

            Point[] pArr = points.ToArray();
            for (int i = 0; i < pArr.Length; i++)
            {
                pArr[i].X = FirstPoint.X + (int)Math.Round((pArr[i].X - oldFirstPoint.X) * scale.X);
                pArr[i].Y = FirstPoint.Y + (int)Math.Round((pArr[i].Y - oldFirstPoint.Y) * scale.Y);
            }
            points.Clear();
            points.AddRange(pArr);
        }

        public override void DrawDash(Graphics g, Point margin)
        {
            Point[] pArr = points.ToArray();
            for (int i = 0; i < pArr.Length; i++)
            {
                pArr[i].X += margin.X;
                pArr[i].Y += margin.Y;
            }
            g.DrawCurve(DashPen, pArr);
        }

        public override List<Control> GetControls()
        {
            var controls = new List<Control>
            {
                GetLineWidthControl(),
                GetLineColorControl(),
                GetPointsCoordinatesControl()
            };
            return controls;
        }

        protected Control GetPointsCoordinatesControl()
        {
            var panel = new FlowLayoutPanel()
            {
                Size = new Size(290, 170)
            };
            var label = new Label()
            {
                Text = "Точки:",
                Size = new Size(40, 25),
                TextAlign = ContentAlignment.MiddleLeft
            };

            string coordinates = "";
            foreach (Point point in points)
            {
                coordinates += string.Format("{0},{1};", point.X, point.Y);
            }
            var textBox = new TextBox()
            {
                Text = coordinates,
                Size = new Size(230, 170),
                Multiline = true
            };

            panel.Controls.AddRange(new Control[] { label, textBox });
            return panel;
        }

        public override void SetParameters(Control.ControlCollection controls)
        {
            var lineWidthControls = ((FlowLayoutPanel)controls[0]).Controls;
            SetLineWidth(lineWidthControls);
            var lineColorControls = ((FlowLayoutPanel)controls[1]).Controls;
            SetLineColor(lineColorControls);
            var pointsCoordinatesControls = ((FlowLayoutPanel)controls[2]).Controls;
            SetPointsCoordinates(pointsCoordinatesControls);
        }

        protected void SetPointsCoordinates(Control.ControlCollection controls)
        {
            var text = controls[1].Text;
            var pointStrings = text.Substring(0, text.Length - 1).Split(';');
            var newPoints = new List<Point>();
            var leftTop = FirstPoint;
            var rightBottom = SecondPoint;
            foreach (var pointString in pointStrings)
            {
                var pointCoordinates = pointString.Split(',');
                if (!int.TryParse(pointCoordinates[0], out int x))
                {
                    return;
                }
                if (!int.TryParse(pointCoordinates[1], out int y))
                {
                    return;
                }
                var point = new Point(x, y);
                newPoints.Add(point);
                leftTop.X = Math.Min(leftTop.X, x);
                leftTop.Y = Math.Min(leftTop.Y, y);
                rightBottom.X = Math.Max(rightBottom.X, x);
                rightBottom.Y = Math.Max(rightBottom.Y, y);
            }
            FirstPoint = leftTop;
            SecondPoint = rightBottom;
            points = newPoints;
        }
    }
}
